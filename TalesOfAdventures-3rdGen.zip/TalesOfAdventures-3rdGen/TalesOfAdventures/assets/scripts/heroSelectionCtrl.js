cc.Class({
    extends: cc.Component,

    properties: {
    },


    onLoad () {},

    start () {

    },

    // update (dt) {},
});
