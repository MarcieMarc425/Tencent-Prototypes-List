"use strict";
cc._RF.push(module, '1662a+QhlRGt56kMf6KQP5G', 'heroSelectionCtrl');
// scripts/heroSelectionCtrl.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    onLoad: function onLoad() {},
    start: function start() {}
}

// update (dt) {},
);

cc._RF.pop();