var app = require('express')();
var http = require('http').Server(app);
var io = require('socket.io')(http);
var request = require('request');

const PORT_NUM = 8081;

var connectedQueue = [];
var battleQueue = [];
var room = [];

app.get('*', function (req, res) {});

io.on('connect', socket => {
    connectedQueue.push(socket.id);
    console.log('Players currently connected: ' + connectedQueue.length);
    console.log('Players currently in queue:' + battleQueue.length);
    
    socket.on('request-battle', (res, callback) => {
        var found = false;
        for(var i = 0; i < battleQueue.length; i++) {
            if(battleQueue[i] == socket.id)
                found = true;
        }
        if(found)
            return;
        else {
            battleQueue.push(socket.id);
            console.log('Players currently connected: ' + connectedQueue.length);
            console.log('Players currently in queue:' + battleQueue.length);
            if(battleQueue.length != 2) {
                callback('waiting');
            } else {
                for(var i = 0; i < battleQueue.length; i++) {
                    console.log(battleQueue[i]);
                    var playersObj = new Object();
                    if(i == 0)
                        playersObj.p1 = battleQueue[i];
                    else(i == 1)
                        playersObj.p2 = battleQueue[i];
                    io.to(battleQueue[i]).emit('player-ready', 'ready');
                    room.push(playersObj);
                    battleQueue.splice(i, 1);
                    i -= 1;
                }
                console.log(battleQueue);
                callback('matched');
            }    
        }
    });
    
    socket.on('join-battle', res => {
        
    });

    socket.on('disconnect', res => {
        connectedQueue.splice(socket.id, 1);
        battleQueue.splice(socket.id, 1);
        console.log('User has disconnected.');
        console.log('Players currently connected: ' + connectedQueue.length);
        console.log('Players currently in queue:' + battleQueue.length);
    });
});

function initRoom() {
    
}

http.listen(PORT_NUM, () => {
    console.log('Server listening on port ' + PORT_NUM + '...');
});