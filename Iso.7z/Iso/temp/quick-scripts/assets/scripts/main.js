(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/main.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'e7fac/la/NFg42ZzqDrBaDn', 'main', __filename);
// scripts/main.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        player1Pos: {
            default: null,
            type: cc.Sprite
        },
        player2Pos: {
            default: null,
            type: cc.Sprite
        },
        up_left: {
            default: null,
            type: cc.Button
        },
        up_right: {
            default: null,
            type: cc.Button
        },
        down_left: {
            default: null,
            type: cc.Button
        },
        down_right: {
            default: null,
            type: cc.Button
        }
    },

    onLoad: function onLoad() {
        this.p1Pos = [0, 0];
        this.player1Pos.node.position = cc.p(0, -99.5);
        this.player2Pos.node.position = cc.p(0, 150.7);
    },
    start: function start() {},
    moveUpLeft: function moveUpLeft() {
        if (this.p1Pos[1] + 1 <= 4) {
            this.p1Pos[1] += 1;
            this.player1Pos.node.x -= 69.5;
            this.player1Pos.node.y += 31.2;
        }
    },
    moveUpRight: function moveUpRight() {
        if (this.p1Pos[0] + 1 <= 4) {
            this.p1Pos[0] += 1;
            this.player1Pos.node.x += 69.5;
            this.player1Pos.node.y += 31.2;
        }
    },
    moveDownLeft: function moveDownLeft() {
        if (this.p1Pos[0] - 1 >= 0) {
            this.p1Pos[0] -= 1;
            this.player1Pos.node.x -= 69.5;
            this.player1Pos.node.y -= 31.2;
        }
    },
    moveDownRight: function moveDownRight() {
        if (this.p1Pos[1] - 1 >= 0) {
            this.p1Pos[1] -= 1;
            this.player1Pos.node.x += 69.5;
            this.player1Pos.node.y -= 31.2;
        }
    }
}

// update (dt) {},
);

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=main.js.map
        