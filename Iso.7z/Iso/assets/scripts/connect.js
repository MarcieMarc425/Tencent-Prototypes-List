// const io = require('../../weapp.socket.io');
// const IOURL = 'ws://127.0.0.1:8081';
// const socket = io(IOURL);

require('./socket.io');
var socket = io('ws://localhost:8081');

cc.Class({
    extends: cc.Component,

    properties: {
        notification: {
            default: null,
            type: cc.Label
        },
        connectBtn: {
            default: null,
            type: cc.Button
        }
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        this.notification.string = '没加入连接';
        // this.socket2 = io('ws://localhost:8081');
        socket.on('player-ready', msg => {
            if(msg == 'ready')
                cc.director.loadScene('main.fire');
        });
    },

    start () {

    },

    connectBtnOnClicked () {
        var _this = this;
        socket.emit('request-battle', 'request', status => {
            if(status == 'waiting')
                _this.notification.string = '在等待其他玩家连接中...';
            else {
                socket.emit('join-battle', 'enter');
                _this.notification.string = '已找到其他玩家!';
            }
        });
    },

    update (dt) {
    },
});