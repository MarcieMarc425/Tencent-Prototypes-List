const io = require('../weapp.socket.io');
const IOURL = 'ws://127.0.0.1:8081';
const socket = io(IOURL);

require = function () {
    function r(e, n, t) {
        function o(i, f) {
            if (!n[i]) {
                if (!e[i]) {
                    var c = "function" == typeof require && require;
                    if (!f && c) return c(i, !0);
                    if (u) return u(i, !0);
                    var a = new Error("Cannot find module '" + i + "'");
                    throw a.code = "MODULE_NOT_FOUND", a;
                }
                var p = n[i] = {
                    exports: {}
                };
                e[i][0].call(p.exports, function (r) {
                    var n = e[i][1][r];
                    return o(n || r);
                }, p, p.exports, r, e, n, t);
            }
            return n[i].exports;
        }
        for (var u = "function" == typeof require && require, i = 0; i < t.length; i++) o(t[i]);
        return o;
    }
    return r;
}()({
    connect: [function (require, module, exports) {
        "use strict";
        cc._RF.push(module, "391d9Qyg35GULQ4buTcPwR1", "connect");
        "use strict";
        cc.Class({
            extends: cc.Component,
            properties: {
                notification: {
                    default: null,
                    type: cc.Label
                },
                connectBtn: {
                    default: null,
                    type: cc.Button
                }
            },
            onLoad: function onLoad() {
                this.notification.string = "没加入连接";
                socket.on('player-ready', msg => {
                    console.log(msg);
                });                                
            },
            start: function start() {},
            connectBtnOnClicked: function connectBtnOnClicked() {
                var _this = this;
                socket.emit('request-battle', 'request', status => {
                    if(status == 'waiting')
                        _this.notification.string = '在等待其他玩家连接中...';
                    else {
                        socket.emit('join-battle', 'join');
                        _this.notification.string = '已找到其他玩家!';
                    }
                });
            },
            update: function(dt) {
            }           
        });
        cc._RF.pop();
    }, {}],
    main: [function (require, module, exports) {
        "use strict";
        cc._RF.push(module, "e7fac/la/NFg42ZzqDrBaDn", "main");
        "use strict";
        cc.Class({
            extends: cc.Component,
            properties: {
                player1Pos: {
                    default: null,
                    type: cc.Sprite
                },
                player2Pos: {
                    default: null,
                    type: cc.Sprite
                },
                up_left: {
                    default: null,
                    type: cc.Button
                },
                up_right: {
                    default: null,
                    type: cc.Button
                },
                down_left: {
                    default: null,
                    type: cc.Button
                },
                down_right: {
                    default: null,
                    type: cc.Button
                }
            },
            onLoad: function onLoad() {
                this.p1Pos = [0, 0];
                this.player1Pos.node.position = cc.p(0, -99.5);
                this.player2Pos.node.position = cc.p(0, 150.7);
            },
            start: function start() {},
            moveUpLeft: function moveUpLeft() {
                if (this.p1Pos[1] + 1 <= 4) {
                    this.p1Pos[1] += 1;
                    this.player1Pos.node.x -= 69.5;
                    this.player1Pos.node.y += 31.2;
                }
            },
            moveUpRight: function moveUpRight() {
                if (this.p1Pos[0] + 1 <= 4) {
                    this.p1Pos[0] += 1;
                    this.player1Pos.node.x += 69.5;
                    this.player1Pos.node.y += 31.2;
                }
            },
            moveDownLeft: function moveDownLeft() {
                if (this.p1Pos[0] - 1 >= 0) {
                    this.p1Pos[0] -= 1;
                    this.player1Pos.node.x -= 69.5;
                    this.player1Pos.node.y -= 31.2;
                }
            },
            moveDownRight: function moveDownRight() {
                if (this.p1Pos[1] - 1 >= 0) {
                    this.p1Pos[1] -= 1;
                    this.player1Pos.node.x += 69.5;
                    this.player1Pos.node.y -= 31.2;
                }
            }
        });
        cc._RF.pop();
    }, {}]
}, {}, ["connect", "main"]);