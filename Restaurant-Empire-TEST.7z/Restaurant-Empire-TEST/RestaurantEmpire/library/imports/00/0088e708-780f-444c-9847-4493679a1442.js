"use strict";
cc._RF.push(module, '0088ecIeA9ETJhHRJNnmhRC', 'global');
// scripts/global.js

'use strict';

window['global'] = {
    seeds: 0,

    sendSeed: function sendSeed() {
        var seedTimer = setInterval(function () {
            global.seeds--;
            console.log('Global seeds:' + global.seeds);
            if (global.seeds <= 0) {
                clearInterval(seedTimer);
                console.log('All seeds are sent');
            }
        }, 3000);
    }
};

cc._RF.pop();