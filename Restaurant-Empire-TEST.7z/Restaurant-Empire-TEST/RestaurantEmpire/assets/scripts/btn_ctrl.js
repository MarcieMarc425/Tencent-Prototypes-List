// Learn cc.Class:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //     // ATTRIBUTES:
        //     default: null,        // The default value will be used only when the component attaching
        //                           // to a node for the first time
        //     type: cc.SpriteFrame, // optional, default is typeof default
        //     serializable: true,   // optional, default is true
        // },
        // bar: {
        //     get () {
        //         return this._bar;
        //     },
        //     set (value) {
        //         this._bar = value;
        //     }
        // },

        buttonPlus: cc.Button,
        buttonMinus: cc.Button,
        buttonSend: cc.Button,
        display: cc.Label,
        speed: 10,
        horizontalBar: {
            type: cc.ProgressBar,
            default: null
        },
        isSendClicked: {
            type: cc.Boolean,
            default: false,
        },
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    onLoad: function() {
        var num = 0;
        this.display.getComponent(cc.Label).string = num;
        this.horizontalBar.progress = 0;
        this.speed = 0.5;
        this.isSendClicked = false;
    },

    start () {
    },

    // update: function (dt) {
    //     if(this.isSendClicked && this.numToSend > 0)
    //         this._updateProgressBar(this.horizontalBar, dt);
    //     if (this.numToSend <= 0){
    //         this.isSendClicked = false;
    //     }
    // },

    // _updateProgressBar: function(progressBar, dt) {
    //     var progress = progressBar.progress;
    //     if(progress < 1.0){
    //         progress += dt * this.speed;
    //     }
    //     if(progress >= 1.0){
    //         progress = 0;
    //         this.numToSend -= 1;
    //         cc.log(this.numToSend);
    //     }
    //     progressBar.progress = progress;
    // },

    onButtonPlusPressed: function() {
        var num = this.display.getComponent(cc.Label).string;
        num += 1;
        this.display.getComponent(cc.Label).string = num;
    },

    onButtonMinusPressed: function() {
        var num = this.display.getComponent(cc.Label).string;
        num -= 1;
        if(num < 0){
            this.display.getComponent(cc.Label).string = 0;
        } else {
            this.display.getComponent(cc.Label).string = num;
        }
    },

    onButtonSendPressed: function() {
        var numSend = parseInt(this.display.getComponent(cc.Label).string);
        global.seeds = numSend;
        this.isSendClicked = true;
        this.display.getComponent(cc.Label).string = 0;
        global.sendSeed();
    }
    

    // update (dt) {},
});
