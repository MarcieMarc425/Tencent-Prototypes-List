window['global'] = {
    seeds: 0,

    sendSeed: function() {
        var seedTimer = setInterval(function(){
            global.seeds--;
            console.log('Global seeds:'+global.seeds);
            if(global.seeds <= 0){
                clearInterval(seedTimer);
                console.log('All seeds are sent');
            }    
        }, 3000);
    },
}