(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/global.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '0088ecIeA9ETJhHRJNnmhRC', 'global', __filename);
// scripts/global.js

'use strict';

window['global'] = {
    seeds: 0,

    sendSeed: function sendSeed() {
        var seedTimer = setInterval(function () {
            global.seeds--;
            console.log('Global seeds:' + global.seeds);
            if (global.seeds <= 0) {
                clearInterval(seedTimer);
                console.log('All seeds are sent');
            }
        }, 3000);
    }
};

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=global.js.map
        