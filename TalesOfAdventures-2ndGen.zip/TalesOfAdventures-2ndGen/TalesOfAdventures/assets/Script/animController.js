// Learn cc.Class:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
        p1fireBall: {
            default: null,
            type: cc.Prefab
        },

        p2fireBall: {
            default: null,
            type: cc.Prefab
        },
        
        p1dmgLabel: {
            default: null,
            type: cc.Prefab
        },

        p2dmgLabel: {
            default: null,
            type: cc.Prefab
        },

        p1dotBuff: {
            default: null,
            type: cc.Prefab
        },

        p2dotBuff: {
            default: null,
            type: cc.Prefab
        },

        p1melee: {
            default: null,
            type: cc.Prefab
        },

        p2melee: {
            default: null,
            type: cc.Prefab
        },

        p1flash: {
            default: null,
            type: cc.Prefab
        },

        p2flash: {
            default: null,
            type: cc.Prefab
        },

        p1debuff: {
            default: null,
            type: cc.Prefab
        },

        p2debuff: {
            default: null,
            type: cc.Prefab
        },

        p1flashObj: {
            default: null,
            type: cc.Prefab
        },

        p2flashObj: {
            default: null,
            type: cc.Prefab
        }
    },

    // ANIMATION:

    // Switching out heroes
    switchOut() {
        var node = this.node.parent;
        
        if(Global.animQueue[0].player == 'player-1') {
            var anim = node.getChildByName('player-1').getChildByName('hero-model').getComponent(cc.Animation);
            anim.play('player-switchOut');
            var anim1 = anim.getAnimationState('player-switchOut');
            anim1.on('finished', this.loadHeroModel, this);
            anim1.on('finished', this.switchIn, this);
    
        } else {
            var anim = node.getChildByName('player-2').getChildByName('hero-model').getComponent(cc.Animation);
            anim.play('player-switchOut');
            var anim1 = anim.getAnimationState('player-switchOut');
            anim1.on('finished', this.loadHeroModel, this);
            anim1.on('finished', this.switchIn, this);    
        }
    },

    // Load hero model
    loadHeroModel() {
        var node = this.node.parent;

        if(Global.animQueue[0].player == 'player-1') {
            cc.loader.loadRes('json/player1-hero-list', function(err, heroList) {
                var url = cc.url.raw(heroList.current_fireteam[0].heroModel);
                var img = cc.textureCache.addImage(url);
                node.getChildByName('player-1').getChildByName('hero-model').getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(img);
            })    
        } else {
            cc.loader.loadRes('json/player2-hero-list', function(err, heroList) {
                var url = cc.url.raw(heroList.current_fireteam[0].heroModel);
                var img = cc.textureCache.addImage(url);
                node.getChildByName('player-2').getChildByName('hero-model').getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(img);
            })    
        }
    },
    
    // Switching in heroes
    switchIn() {
        var node = this.node.parent;
        if(Global.animQueue[0].player == 'player-1') {
            var anim = node.getChildByName('player-1').getChildByName('hero-model').getComponent(cc.Animation);
            anim.play('player-switchIn');
            var anim1 = anim.getAnimationState('player-switchIn');
            anim1.on('finished', this.unloadQueue, this);    
        } else {
            var anim = node.getChildByName('player-2').getChildByName('hero-model').getComponent(cc.Animation);
            anim.play('player-switchIn');          
            var anim1 = anim.getAnimationState('player-switchIn');
            anim1.on('finished', this.unloadQueue, this);    
        }
    },

    // Fireball animation
    fireBallAni() {
        var node = this.node.parent;

        if(Global.animQueue[0].player == 'player-1') {
            var fireBall = cc.instantiate(this.p1fireBall);
            node.addChild(fireBall);
            fireBall.getComponent('fireball').init();    
        } else {
            var fireBall = cc.instantiate(this.p2fireBall);
            node.addChild(fireBall);
            fireBall.getComponent('fireball').init();    
        }
    },

    // Player model melee animation
    playerMeleeAni() {
        var node = this.node.parent;

        if(Global.animQueue[0].player == 'player-1') {
            var anim = node.getChildByName('player-1').getChildByName('hero-model').getComponent(cc.Animation);
            anim.play('player-melee');
            var anim1 = anim.getAnimationState('player-melee');
            anim1.on('finished', this.slashAni, this);
        } else {
            var anim = node.getChildByName('player-2').getChildByName('hero-model').getComponent(cc.Animation);
            anim.play('player-melee');
            var anim1 = anim.getAnimationState('player-melee');
            anim1.on('finished', this.slashAni, this);
        }
    },

    // Melee Slash prefab animation
    slashAni() {
        var node = this.node.parent;

        if(Global.animQueue[0].player == 'player-1') {
            var melee = cc.instantiate(this.p1melee);
            node.addChild(melee);
            melee.getComponent('slash').init();
        } else {
            var melee = cc.instantiate(this.p2melee);
            node.addChild(melee);
            melee.getComponent('slash').init();
        }
        
    },

    // Flashbang Obj prefab animation
    flashObjAni() {
        var node = this.node.parent;
        
        if(Global.animQueue[0].player == 'player-1') {
            var flash = cc.instantiate(this.p1flashObj);
            node.addChild(flash);
            flash.getComponent('flashbangObj').init();
        } else {
            var flash = cc.instantiate(this.p2flashObj);
            node.addChild(flash);
            flash.getComponent('flashbangObj').init();
        }

    },

    // Flashbang light animation
    flashAni() {
        var node = this.node.parent;
        
        if(Global.animQueue[0].player == 'player-1') {
            var flash = cc.instantiate(this.p1flash);
            node.addChild(flash);
            flash.getComponent('flashbang').init();
        } else {
            var flash = cc.instantiate(this.p2flash);
            node.addChild(flash);
            flash.getComponent('flashbang').init();
        }

    },

    // Player debuff animation
    debuffAni() {
        var node = this.node.parent;

        if(Global.animQueue[0].player == 'player-1') {
            var anim = node.getChildByName('player-1').getChildByName('hero-model').getComponent(cc.Animation);
            anim.playAdditive('player-debuffed');
            var debuff = cc.instantiate(this.p1debuff);
            node.getChildByName('player-1').addChild(debuff);
            debuff.getComponent('debuff').init();
        } else {
            var anim = node.getChildByName('player-2').getChildByName('hero-model').getComponent(cc.Animation);
            anim.playAdditive('player-debuffed');
            var debuff = cc.instantiate(this.p2debuff);
            node.getChildByName('player-2').addChild(debuff);
            debuff.getComponent('debuff').init();
        }
    },

    // Damage animation
    damagedAni() {
        var dmg = Global.animQueue[0].dps;
        var node = this.node.parent;
        if(Global.animQueue[0].player == 'player-1') {
            var anim = node.getChildByName('player-1').getChildByName('hero-model').getComponent(cc.Animation);
            anim.playAdditive('player-damaged');
            var dmgLabel = cc.instantiate(this.p1dmgLabel);
            node.getChildByName('player-1').addChild(dmgLabel);
            dmgLabel.getComponent('dmgLabel').init(dmg);
        } else {
            var anim = node.getChildByName('player-2').getChildByName('hero-model').getComponent(cc.Animation);
            anim.playAdditive('player-damaged');
            var dmgLabel = cc.instantiate(this.p2dmgLabel);
            node.getChildByName('player-2').addChild(dmgLabel);
            dmgLabel.getComponent('dmgLabel').init(dmg);
        }
    },

    dotBuffAni() {
        var node = this.node.parent;

        if(Global.animQueue[0].player == 'player-1') {
            var anim = node.getChildByName('player-1').getChildByName('hero-model').getComponent(cc.Animation);
            anim.playAdditive('player-dotBuffed');
            var dotBuff = cc.instantiate(this.p1dotBuff);
            node.getChildByName('player-1').addChild(dotBuff);
            dotBuff.getComponent('dotBuff').init();
        } else {
            var anim = node.getChildByName('player-2').getChildByName('hero-model').getComponent(cc.Animation);
            anim.playAdditive('player-dotBuffed');
            var dotBuff = cc.instantiate(this.p2dotBuff);
            node.getChildByName('player-2').addChild(dotBuff);
            dotBuff.getComponent('dotBuff').init();
        }
    },

    start () {

    },

    unloadQueue() {
        Global.animQueue.splice(0, 1);
        Global.animStatus = null;
    },

    update(dt) {
        if(Global.animStatus == null) {
            if(Global.animQueue.length != 0) {
                Global.animStatus = 'In Progress';
                if(Global.animQueue[0].name == 'switch')
                    this.switchOut();
                if(Global.animQueue[0].name == 'fireball')
                    this.fireBallAni();
                if(Global.animQueue[0].name == 'damage') 
                    this.damagedAni();
                if(Global.animQueue[0].name == 'dotBuff') 
                    this.dotBuffAni();
                if(Global.animQueue[0].name == 'melee')
                    this.playerMeleeAni();
                if(Global.animQueue[0].name == 'flashObj')
                    this.flashObjAni();
                if(Global.animQueue[0].name == 'flash')
                    this.flashAni();
                if(Global.animQueue[0].name == 'debuff')
                    this.debuffAni();
            }
        }
    }
    // update (dt) {},
});
