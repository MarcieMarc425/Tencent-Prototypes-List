// Learn cc.Class:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //     // ATTRIBUTES:
        //     default: null,        // The default value will be used only when the component attaching
        //                           // to a node for the first time
        //     type: cc.SpriteFrame, // optional, default is typeof default
        //     serializable: true,   // optional, default is true
        // },
        // bar: {
        //     get () {
        //         return this._bar;
        //     },
        //     set (value) {
        //         this._bar = value;
        //     }
        // },
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    onLoad() {

        var node = this.node.parent;

        // Set Interval Timer
        this.updateInterval = 0.15;
        this.updateTimer = 0;

        node.turn = 'player-1';

        node.turnCounter = 1;
        node.getChildByName('turnCounter').getChildByName('turn-count').getComponent(cc.Label).string = node.turnCounter;

        node.player1Action = null;
        node.player2Action = null;

        // Load player1
        cc.loader.loadRes('json/player1-hero-list', function (err, heroList) {
            for (var i = 0; i < heroList.current_fireteam.length; i++) {
                var currentHero = heroList.current_fireteam[i];
                // Load hero sidebar
                var currentIconNode = 'heroIcon' + (i + 1);
                var heroIcon = node.getChildByName('player-1').getChildByName('hero-sidebar').getChildByName(currentIconNode).getChildByName('hero-icon');
                var url = cc.url.raw(currentHero.miniUrl);
                var img = cc.textureCache.addImage(url);
                heroIcon.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(img);
                var heroHealth = heroIcon.parent.getChildByName('hero-hp');
                heroHealth.getComponent(cc.Label).string = '生命:' + currentHero.healthCurrent;

                // Load first hero info
                if (i == 0) {
                    // Load first hero health bar
                    var healthProgress = node.getChildByName('player-1').getChildByName('health-progress');
                    healthProgress.getComponent(cc.ProgressBar).progress = currentHero.healthCurrent / currentHero.healthTotal;
                    var healthLabel = node.getChildByName('player-1').getChildByName('health-label');
                    healthLabel.getComponent(cc.Label).string = currentHero.healthCurrent + '/' + currentHero.healthTotal;

                    // Load first hero name
                    var heroName = node.getChildByName('player-1').getChildByName('hero-name');
                    heroName.getComponent(cc.Label).string = currentHero.name;

                    // Load first hero skill
                    var heroSkill1Icon = node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('skill1').getChildByName('empty-skill');
                    var heroSkill2Icon = node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('skill2').getChildByName('empty-skill');
                    var heroSkill1Name = node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('skill1').getChildByName('skill-name');
                    var heroSkill2Name = node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('skill2').getChildByName('skill-name');
                    var heroChangeName = node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('changeBtn').getChildByName('label');
                    var url1 = cc.url.raw(currentHero.skill[0].icon);
                    var url2 = cc.url.raw(currentHero.skill[1].icon);
                    var img1 = cc.textureCache.addImage(url1);
                    var img2 = cc.textureCache.addImage(url2);
                    heroSkill1Icon.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(img1);
                    heroSkill2Icon.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(img2);
                    heroSkill1Name.getComponent(cc.Label).string = currentHero.skill[0].name;
                    heroSkill2Name.getComponent(cc.Label).string = currentHero.skill[1].name;
                    heroChangeName.getComponent(cc.Label).string = currentHero.skill[2].name;

                    // Load first hero model
                    var url = cc.url.raw(currentHero.heroModel);
                    var img = cc.textureCache.addImage(url);
                    node.getChildByName('player-1').getChildByName('hero-model').getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(img);
                }
            }
        });

        // Load player2
        cc.loader.loadRes('json/player2-hero-list', function (err, heroList) {
            for (var i = 0; i < heroList.current_fireteam.length; i++) {
                var currentHero = heroList.current_fireteam[i];
                // Load hero sidebar
                var currentIconNode = 'heroIcon' + (i + 1);
                var heroIcon = node.getChildByName('player-2').getChildByName('hero-sidebar').getChildByName(currentIconNode).getChildByName('hero-icon');
                var url = cc.url.raw(currentHero.miniUrl);
                var img = cc.textureCache.addImage(url);
                heroIcon.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(img);
                var heroHealth = heroIcon.parent.getChildByName('hero-hp');
                heroHealth.getComponent(cc.Label).string = '生命:' + currentHero.healthCurrent;

                // Load first hero info
                if (i == 0) {
                    // Load first hero health bar
                    var healthProgress = node.getChildByName('player-2').getChildByName('health-progress');
                    healthProgress.getComponent(cc.ProgressBar).progress = currentHero.healthCurrent / currentHero.healthTotal;
                    var healthLabel = node.getChildByName('player-2').getChildByName('health-label');
                    healthLabel.getComponent(cc.Label).string = currentHero.healthCurrent + '/' + currentHero.healthTotal;

                    // Load first hero name
                    var heroName = node.getChildByName('player-2').getChildByName('hero-name');
                    heroName.getComponent(cc.Label).string = currentHero.name;

                    // Load first hero skill
                    var heroSkill1Icon = node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('skill1').getChildByName('empty-skill');
                    var heroSkill2Icon = node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('skill2').getChildByName('empty-skill');
                    var heroSkill1Name = node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('skill1').getChildByName('skill-name');
                    var heroSkill2Name = node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('skill2').getChildByName('skill-name');
                    var heroChangeName = node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('changeBtn').getChildByName('label');
                    var url1 = cc.url.raw(currentHero.skill[0].icon);
                    var url2 = cc.url.raw(currentHero.skill[1].icon);
                    var img1 = cc.textureCache.addImage(url1);
                    var img2 = cc.textureCache.addImage(url2);
                    heroSkill1Icon.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(img1);
                    heroSkill2Icon.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(img2);
                    heroSkill1Name.getComponent(cc.Label).string = currentHero.skill[0].name;
                    heroSkill2Name.getComponent(cc.Label).string = currentHero.skill[1].name;
                    heroChangeName.getComponent(cc.Label).string = currentHero.skill[2].name;

                    // Load first hero model
                    var url = cc.url.raw(currentHero.heroModel);
                    var img = cc.textureCache.addImage(url);
                    node.getChildByName('player-2').getChildByName('hero-model').getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(img);
                }
            }
        });

        // Set skillbar status
        this.isSkill1Clicked = false;
        this.isSkill2Clicked = false;
        this.isChangeBtnClicked = false;

        // Hide confirmation popup
        node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('confirmation').active = false;
        node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('confirmation').active = false;
    },

    start() {

    },

    // When skill 1 icon is clicked
    skill1onClicked() {
        var node = this.node.parent;

        if (!this.isSkill1Clicked) {
            if(node.turn == 'player-1') {
                // White border on click if not yet clicked
                var border = node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('skill1').getChildByName('skill-border');
                var url = cc.url.raw("resources/skill-icon/skill-border-onClick.png");
                var img = cc.textureCache.addImage(url);
                border.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(img);
                this.isSkill1Clicked = true;
                this.isSkill2Clicked = false;
                this.isChangeBtnClicked = false;
            } else {
                // White border on click if not yet clicked
                var border = node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('skill1').getChildByName('skill-border');
                var url = cc.url.raw("resources/skill-icon/skill-border-onClick.png");
                var img = cc.textureCache.addImage(url);
                border.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(img);
                this.isSkill1Clicked = true;
                this.isSkill2Clicked = false;
                this.isChangeBtnClicked = false;
            }
        } 

        if(node.turn == 'player-1') {
            // Load skill title and description in confirmation popup
            cc.loader.loadRes('json/player1-hero-list', function (err, heroList) {
                var currentHero = heroList.current_fireteam[0];
                // If skill1 is active
                var confirmNode = node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('confirmation');
                confirmNode.getChildByName('skillTitle').getComponent(cc.Label).string = '技能1 - ' + currentHero.skill[0].name;
                cc.loader.loadRes('skill-info/' + currentHero.skill[0].name, function (err, description) {
                    confirmNode.getChildByName('skillDesc').getComponent(cc.Label).string = description;
                });
            });

            // Confirmation pop up
            node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('confirmation').active = true;

            // Disable skill1, skill2, changeBtn interactable
            var btn = node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('skill1');
            btn.getComponent(cc.Button).interactable = false;

            btn = node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('skill2');
            btn.getComponent(cc.Button).interactable = false;

            btn = node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('changeBtn').getChildByName('change');
            btn.getComponent(cc.Button).interactable = false;
        } else {
            // Load skill title and description in confirmation popup
            cc.loader.loadRes('json/player2-hero-list', function (err, heroList) {
                var currentHero = heroList.current_fireteam[0];
                // If skill1 is active
                var confirmNode = node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('confirmation');
                confirmNode.getChildByName('skillTitle').getComponent(cc.Label).string = '技能1 - ' + currentHero.skill[0].name;
                cc.loader.loadRes('skill-info/' + currentHero.skill[0].name, function (err, description) {
                    confirmNode.getChildByName('skillDesc').getComponent(cc.Label).string = description;
                });
            });

            // Confirmation pop up
            node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('confirmation').active = true;

            // Disable skill1, skill2, changeBtn interactable
            var btn = node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('skill1');
            btn.getComponent(cc.Button).interactable = false;

            btn = node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('skill2');
            btn.getComponent(cc.Button).interactable = false;

            btn = node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('changeBtn').getChildByName('change');
            btn.getComponent(cc.Button).interactable = false;        
        }
    },

    // When skill 2 icon is clicked
    skill2onClicked() {
        var node = this.node.parent;

        if (!this.isSkill2Clicked) {
            if(node.turn == 'player-1') {
                // White border on click if not yet clicked
                var border = node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('skill2').getChildByName('skill-border');
                var url = cc.url.raw("resources/skill-icon/skill-border-onClick.png");
                var img = cc.textureCache.addImage(url);
                border.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(img);
                this.isSkill2Clicked = true;
                this.isSkill1Clicked = false;
                this.isChangeBtnClicked = false;
            } else {
                // White border on click if not yet clicked
                var border = node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('skill2').getChildByName('skill-border');
                var url = cc.url.raw("resources/skill-icon/skill-border-onClick.png");
                var img = cc.textureCache.addImage(url);
                border.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(img);
                this.isSkill2Clicked = true;
                this.isSkill1Clicked = false;
                this.isChangeBtnClicked = false;
            }
        } 

        if(node.turn == 'player-1') {
            // Load skill title and description in confirmation popup
            cc.loader.loadRes('json/player1-hero-list', function (err, heroList) {
                var currentHero = heroList.current_fireteam[0];
                // If skill1 is active
                var confirmNode = node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('confirmation');
                confirmNode.getChildByName('skillTitle').getComponent(cc.Label).string = '技能2 - ' + currentHero.skill[1].name;
                cc.loader.loadRes('skill-info/' + currentHero.skill[1].name, function (err, description) {
                    confirmNode.getChildByName('skillDesc').getComponent(cc.Label).string = description;
                });
            });

            // Confirmation pop up
            node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('confirmation').active = true;

            // Disable skill1, skill2, changeBtn interactable
            var btn = node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('skill1');
            btn.getComponent(cc.Button).interactable = false;

            btn = node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('skill2');
            btn.getComponent(cc.Button).interactable = false;

            btn = node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('changeBtn').getChildByName('change');
            btn.getComponent(cc.Button).interactable = false;
        } else {
            // Load skill title and description in confirmation popup
            cc.loader.loadRes('json/player2-hero-list', function (err, heroList) {
                var currentHero = heroList.current_fireteam[0];
                // If skill1 is active
                var confirmNode = node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('confirmation');
                confirmNode.getChildByName('skillTitle').getComponent(cc.Label).string = '技能2 - ' + currentHero.skill[1].name;
                cc.loader.loadRes('skill-info/' + currentHero.skill[1].name, function (err, description) {
                    confirmNode.getChildByName('skillDesc').getComponent(cc.Label).string = description;
                });
            });

            // Confirmation pop up
            node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('confirmation').active = true;

            // Disable skill1, skill2, changeBtn interactable
            var btn = node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('skill1');
            btn.getComponent(cc.Button).interactable = false;

            btn = node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('skill2');
            btn.getComponent(cc.Button).interactable = false;

            btn = node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('changeBtn').getChildByName('change');
            btn.getComponent(cc.Button).interactable = false;        
        }
    },

    // When change btn is clicked
    changeBtnOnClicked() {
        var node = this.node.parent;

        if (!this.isChangeBtnClicked) {
            if(node.turn == 'player-1') {
                // White border on click if not yet clicked
                var border = node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('changeBtn').getChildByName('change');
                var url = cc.url.raw("resources/skill-icon/changeOnClick.png");
                var img = cc.textureCache.addImage(url);
                border.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(img);
                this.isSkill2Clicked = false;
                this.isSkill1Clicked = false;
                this.isChangeBtnClicked = true;
            } else {
                // White border on click if not yet clicked
                var border = node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('changeBtn').getChildByName('change');
                var url = cc.url.raw("resources/skill-icon/changeOnClick.png");
                var img = cc.textureCache.addImage(url);
                border.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(img);
                this.isSkill2Clicked = false;
                this.isSkill1Clicked = false;
                this.isChangeBtnClicked = true;
            }
        } 

        if(node.turn == 'player-1') {
            // Load skill title and description in confirmation popup
            cc.loader.loadRes('json/player1-hero-list', function (err, heroList) {
                var currentHero = heroList.current_fireteam[0];
                // If skill1 is active
                var confirmNode = node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('confirmation');
                confirmNode.getChildByName('skillTitle').getComponent(cc.Label).string = '换人 - ' + currentHero.skill[2].name;
                cc.loader.loadRes('skill-info/' + currentHero.skill[2].name, function (err, description) {
                    confirmNode.getChildByName('skillDesc').getComponent(cc.Label).string = description;
                });
            });

            // Confirmation pop up
            node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('confirmation').active = true;

            // Disable skill1, skill2, changeBtn interactable
            var btn = node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('skill1');
            btn.getComponent(cc.Button).interactable = false;

            btn = node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('skill2');
            btn.getComponent(cc.Button).interactable = false;

            btn = node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('changeBtn').getChildByName('change');
            btn.getComponent(cc.Button).interactable = false;
        } else {
            // Load skill title and description in confirmation popup
            cc.loader.loadRes('json/player2-hero-list', function (err, heroList) {
                var currentHero = heroList.current_fireteam[0];
                // If skill1 is active
                var confirmNode = node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('confirmation');
                confirmNode.getChildByName('skillTitle').getComponent(cc.Label).string = '换人 - ' + currentHero.skill[2].name;
                cc.loader.loadRes('skill-info/' + currentHero.skill[2].name, function (err, description) {
                    confirmNode.getChildByName('skillDesc').getComponent(cc.Label).string = description;
                });
            });

            // Confirmation pop up
            node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('confirmation').active = true;

            // Disable skill1, skill2, changeBtn interactable
            var btn = node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('skill1');
            btn.getComponent(cc.Button).interactable = false;

            btn = node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('skill2');
            btn.getComponent(cc.Button).interactable = false;

            btn = node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('changeBtn').getChildByName('change');
            btn.getComponent(cc.Button).interactable = false;        
        }
    },

    // Update hero model
    loadHeroModel() {
        var node = this.node.parent;

        cc.loader.loadRes('json/player1-hero-list', function(err, heroList) {
            var url = cc.url.raw(heroList.current_fireteam[0].heroModel);
            var img = cc.textureCache.addImage(url);
            node.getChildByName('player-1').getChildByName('hero-model').getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(img);
        })

        cc.log('kek');
    },

    // Play animation switcIn
    playSwitchIn() {

        var node = this.node.parent;
        
        var anim = node.getChildByName('player-1').getChildByName('hero-model').getComponent(cc.Animation);

        anim.play('player-switchIn');
    },

    // When yes btn is clicked in confirmation popup
    skillConfirmation_Yes() {
        var node = this.node.parent;

        // If player1 has confirmed, set turn to player2
        // If player2 has confirmed, end the current round
        if(node.turn == 'player-1') {
            // Close confirmation pop up
            node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('confirmation').active = false;

            // Save player1 registered action
            if(this.isSkill1Clicked)
                node.player1Action = 'skill1';
            else if(this.isSkill2Clicked)
                node.player1Action = 'skill2';
            else if(this.isChangeBtnClicked)
                node.player1Action = 'change';

            // reset btnIsClicked = false, and set border = black
            this.isSkill2Clicked = false;
            this.isSkill1Clicked = false;
            this.isChangeBtnClicked = false;


            // Set all buttons to be interactable, set borders to black
            var btn = node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('skill1');
            btn.getComponent(cc.Button).interactable = true;

            btn = node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('skill2');
            btn.getComponent(cc.Button).interactable = true;

            btn = node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('changeBtn').getChildByName('change');
            btn.getComponent(cc.Button).interactable = true;

            var border = node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('skill1').getChildByName('skill-border');
            var url = cc.url.raw("resources/skill-icon/skill-border.png");
            var img = cc.textureCache.addImage(url);
            border.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(img);

            var border = node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('skill2').getChildByName('skill-border');
            var url = cc.url.raw("resources/skill-icon/skill-border.png");
            var img = cc.textureCache.addImage(url);
            border.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(img);

            var border = node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('changeBtn').getChildByName('change');
            var url = cc.url.raw("resources/skill-icon/change.png");
            var img = cc.textureCache.addImage(url);
            border.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(img);

            node.turn = 'player-2';
            
        } else {
            // Close confirmation pop up
            node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('confirmation').active = false;

            // Save player2 registered action
            if(this.isSkill1Clicked)
                node.player2Action = 'skill1';
            else if(this.isSkill2Clicked)
                node.player2Action = 'skill2';
            else if(this.isChangeBtnClicked)
                node.player2Action = 'change';

            // reset btnIsClicked = false, and set border = black
            this.isSkill2Clicked = false;
            this.isSkill1Clicked = false;
            this.isChangeBtnClicked = false;


            // Set all buttons to be interactable, set borders to black
            var btn = node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('skill1');
            btn.getComponent(cc.Button).interactable = true;

            btn = node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('skill2');
            btn.getComponent(cc.Button).interactable = true;

            btn = node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('changeBtn').getChildByName('change');
            btn.getComponent(cc.Button).interactable = true;

            var border = node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('skill1').getChildByName('skill-border');
            var url = cc.url.raw("resources/skill-icon/skill-border.png");
            var img = cc.textureCache.addImage(url);
            border.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(img);

            var border = node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('skill2').getChildByName('skill-border');
            var url = cc.url.raw("resources/skill-icon/skill-border.png");
            var img = cc.textureCache.addImage(url);
            border.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(img);

            var border = node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('changeBtn').getChildByName('change');
            var url = cc.url.raw("resources/skill-icon/change.png");
            var img = cc.textureCache.addImage(url);
            border.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(img);

            this.endTurn();
        }
        
    },

    registerSkill(action, player) {
        var node = this.node.parent;

        if(action == 'change') {
            if(player=='player-1') {
                node.getChildByName('player1Controller').getComponent('player1Controller').loadSkill(action);
                cc.loader.loadRes('json/player1-hero-list', function(err, heroList) {
                    var heroObj = heroList.current_fireteam[0];
                    heroList.current_fireteam.splice(0, 1);
                    heroList.current_fireteam.push(heroObj);
                });
                var animObj = new Object();
                animObj.player = 'player-1';
                animObj.name = 'switch';
                Global.animQueue.push(animObj);
                // node.getChildByName('player1Controller').getComponent('player1Controller').switchOut();
            } else {
                node.getChildByName('player2Controller').getComponent('player2Controller').loadSkill(action); 
                cc.loader.loadRes('json/player2-hero-list', function(err, heroList) {
                    var heroObj = heroList.current_fireteam[0];
                    heroList.current_fireteam.splice(0, 1);
                    heroList.current_fireteam.push(heroObj);
                });
                var animObj = new Object();
                animObj.player = 'player-2';
                animObj.name = 'switch';
                Global.animQueue.push(animObj);
                // node.getChildByName('player2Controller').getComponent('player2Controller').switchOut();
            }

        } else {
            if(player=='player-1') {
                node.getChildByName('player1Controller').getComponent('player1Controller').loadSkill(action);
            } else {
                node.getChildByName('player2Controller').getComponent('player2Controller').loadSkill(action);
            }
        } 
    },

    endTurn() {

        var node = this.node.parent;

        // Load players current status

        // If 1 player is changing hero, register it first, then register the other player
        // If 2 players are changing heroes, register first then second, order doesn't matter because both can't attack
        // If no player is changing hero, register order based on hero's agility
            // If both hero has same agility, then coinflip
        if(node.player1Action == 'change' && node.player2Action != 'change') {
            this.registerSkill(node.player1Action, 'player-1');
            node.getChildByName('player1Controller').getComponent('player1Controller').registerStatus();
            node.getChildByName('player2Controller').getComponent('player2Controller').registerStatus();
            this.registerSkill(node.player2Action, 'player-2');
        } else if(node.player2Action == 'change' && node.player1Action != 'change') {
            this.registerSkill(node.player2Action, 'player-2');
            node.getChildByName('player1Controller').getComponent('player1Controller').registerStatus();
            node.getChildByName('player2Controller').getComponent('player2Controller').registerStatus();
            this.registerSkill(node.player1Action, 'player-1');
        } else if(node.player1Action == 'change' && node.player2Action == 'change') {
            this.registerSkill(node.player1Action, 'player-1');
            this.registerSkill(node.player2Action, 'player-2');
            node.getChildByName('player1Controller').getComponent('player1Controller').registerStatus();
            node.getChildByName('player2Controller').getComponent('player2Controller').registerStatus();
        } else {
            var player1Agile;
            var player2Agile;
            var self = this;
            node.getChildByName('player1Controller').getComponent('player1Controller').registerStatus();
            node.getChildByName('player2Controller').getComponent('player2Controller').registerStatus();
            cc.loader.loadRes('json/player1-hero-list', function(err, heroList) {
                player1Agile = heroList.current_fireteam[0].agilityCurrent;
                cc.loader.loadRes('json/player2-hero-list', function(err, heroList) {
                    player2Agile = heroList.current_fireteam[0].agilityCurrent;
                    if(player1Agile > player2Agile) {
                        self.registerSkill(node.player1Action, 'player-1');
                        self.registerSkill(node.player2Action, 'player-2');    
                    } else if(player2Agile > player1Agile) {
                        self.registerSkill(node.player2Action, 'player2');
                        self.registerSkill(node.player1Action, 'player-1');
                    } else {
                        self.registerSkill(node.player1Action, 'player-1');
                        self.registerSkill(node.player2Action, 'player-2');
                    }
                });
    
            });

            
        }
        node.turnCounter++;
        node.turn = 'player-1';
    },

    // When no btn is clicked in confirmation popup
    skillConfirmation_No() {
        var node = this.node.parent;

        if(node.turn == 'player-1') {
            // Close confirmation pop up
            node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('confirmation').active = false;

            // Enable skill1, skill2, changeBtn interactable
            var btn = node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('skill1');
            btn.getComponent(cc.Button).interactable = true;

            btn = node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('skill2');
            btn.getComponent(cc.Button).interactable = true;

            btn = node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('changeBtn').getChildByName('change');
            btn.getComponent(cc.Button).interactable = true;

            // reset btnIsClicked = false, and set border = black
            this.isSkill2Clicked = false;
            this.isSkill1Clicked = false;
            this.isChangeBtnClicked = false;
            
            var border = node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('skill1').getChildByName('skill-border');
            var url = cc.url.raw("resources/skill-icon/skill-border.png");
            var img = cc.textureCache.addImage(url);
            border.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(img);

            var border = node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('skill2').getChildByName('skill-border');
            var url = cc.url.raw("resources/skill-icon/skill-border.png");
            var img = cc.textureCache.addImage(url);
            border.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(img);

            var border = node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('changeBtn').getChildByName('change');
            var url = cc.url.raw("resources/skill-icon/change.png");
            var img = cc.textureCache.addImage(url);
            border.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(img);

        } else {
            // Close confirmation pop up
            node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('confirmation').active = false;

            // reset btnIsClicked = false, and set border = black
            this.isSkill2Clicked = false;
            this.isSkill1Clicked = false;
            this.isChangeBtnClicked = false;
            
            var border = node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('skill1').getChildByName('skill-border');
            var url = cc.url.raw("resources/skill-icon/skill-border.png");
            var img = cc.textureCache.addImage(url);
            border.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(img);

            var border = node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('skill2').getChildByName('skill-border');
            var url = cc.url.raw("resources/skill-icon/skill-border.png");
            var img = cc.textureCache.addImage(url);
            border.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(img);

            var border = node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('changeBtn').getChildByName('change');
            var url = cc.url.raw("resources/skill-icon/change.png");
            var img = cc.textureCache.addImage(url);
            border.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(img);
            
            // Enable skill1, skill2, changeBtn interactable
            var btn = node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('skill1');
            btn.getComponent(cc.Button).interactable = true;

            btn = node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('skill2');
            btn.getComponent(cc.Button).interactable = true;

            btn = node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('changeBtn').getChildByName('change');
            btn.getComponent(cc.Button).interactable = true;
            
        }

    },

    update(dt) {
        this.updateTimer += dt;
        if (this.updateTimer < this.updateInterval) {
            return;
        }
        this.updateTimer = 0;

        var node = this.node.parent;

        node.getChildByName('turnCounter').getChildByName('turn-count').getComponent(cc.Label).string = node.turnCounter;

        // Hide player 2 skillbar if turn == player 1, and vice versa
        if(node.turn == 'player-1') {
            node.getChildByName('player-1').getChildByName('hero-skillbar').active = true;
            node.getChildByName('player-2').getChildByName('hero-skillbar').active = false;
            node.getChildByName('turnNotification').getComponent(cc.Label).string = '<< 玩家1请选择技能';
            node.getChildByName('turnNotification2').getComponent(cc.Label).string = '玩家2准备中 >>'
        } else {
            node.getChildByName('player-1').getChildByName('hero-skillbar').active = false;
            node.getChildByName('player-2').getChildByName('hero-skillbar').active = true;
            node.getChildByName('turnNotification').getComponent(cc.Label).string = '玩家2请选择技能 >>';
            node.getChildByName('turnNotification2').getComponent(cc.Label).string = '<< 玩家1准备好'
        }

        // Update player1 hero display - healthbar, name, skill1/2, hero sidebar
        cc.loader.loadRes('json/player1-hero-list', function (err, heroList) {
            for (var i = 0; i < heroList.current_fireteam.length; i++) {
                var currentHero = heroList.current_fireteam[i];
                // Load hero sidebar
                var currentIconNode = 'heroIcon' + (i + 1);
                var heroIcon = node.getChildByName('player-1').getChildByName('hero-sidebar').getChildByName(currentIconNode).getChildByName('hero-icon');
                var url = cc.url.raw(currentHero.miniUrl);
                var img = cc.textureCache.addImage(url);
                heroIcon.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(img);
                var heroHealth = heroIcon.parent.getChildByName('hero-hp');
                heroHealth.getComponent(cc.Label).string = '生命:' + currentHero.healthCurrent;

                // Load first hero info
                if (i == 0) {
                    // Load first hero health bar
                    var healthProgress = node.getChildByName('player-1').getChildByName('health-progress');
                    healthProgress.getComponent(cc.ProgressBar).progress = currentHero.healthCurrent / currentHero.healthTotal;
                    var healthLabel = node.getChildByName('player-1').getChildByName('health-label');
                    healthLabel.getComponent(cc.Label).string = currentHero.healthCurrent + '/' + currentHero.healthTotal;

                    // Load first hero name
                    var heroName = node.getChildByName('player-1').getChildByName('hero-name');
                    heroName.getComponent(cc.Label).string = currentHero.name;

                    // Load first hero skill
                    var heroSkill1Icon = node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('skill1').getChildByName('empty-skill');
                    var heroSkill2Icon = node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('skill2').getChildByName('empty-skill');
                    var heroSkill1Name = node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('skill1').getChildByName('skill-name');
                    var heroSkill2Name = node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('skill2').getChildByName('skill-name');
                    var heroChangeName = node.getChildByName('player-1').getChildByName('hero-skillbar').getChildByName('changeBtn').getChildByName('label');
                    var url1 = cc.url.raw(currentHero.skill[0].icon);
                    var url2 = cc.url.raw(currentHero.skill[1].icon);
                    var img1 = cc.textureCache.addImage(url1);
                    var img2 = cc.textureCache.addImage(url2);
                    heroSkill1Icon.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(img1);
                    heroSkill2Icon.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(img2);
                    heroSkill1Name.getComponent(cc.Label).string = currentHero.skill[0].name;
                    heroSkill2Name.getComponent(cc.Label).string = currentHero.skill[1].name;
                    heroChangeName.getComponent(cc.Label).string = currentHero.skill[2].name;
                }
            }
        });

        // Update player2 hero display - healthbar, name, skill1/2, hero sidebar
        cc.loader.loadRes('json/player2-hero-list', function (err, heroList) {
            for (var i = 0; i < heroList.current_fireteam.length; i++) {
                var currentHero = heroList.current_fireteam[i];
                // Load hero sidebar
                var currentIconNode = 'heroIcon' + (i + 1);
                var heroIcon = node.getChildByName('player-2').getChildByName('hero-sidebar').getChildByName(currentIconNode).getChildByName('hero-icon');
                var url = cc.url.raw(currentHero.miniUrl);
                var img = cc.textureCache.addImage(url);
                heroIcon.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(img);
                var heroHealth = heroIcon.parent.getChildByName('hero-hp');
                heroHealth.getComponent(cc.Label).string = '生命:' + currentHero.healthCurrent;

                // Load first hero info
                if (i == 0) {
                    // Load first hero health bar
                    var healthProgress = node.getChildByName('player-2').getChildByName('health-progress');
                    healthProgress.getComponent(cc.ProgressBar).progress = currentHero.healthCurrent / currentHero.healthTotal;
                    var healthLabel = node.getChildByName('player-2').getChildByName('health-label');
                    healthLabel.getComponent(cc.Label).string = currentHero.healthCurrent + '/' + currentHero.healthTotal;

                    // Load first hero name
                    var heroName = node.getChildByName('player-2').getChildByName('hero-name');
                    heroName.getComponent(cc.Label).string = currentHero.name;

                    // Load first hero skill
                    var heroSkill1Icon = node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('skill1').getChildByName('empty-skill');
                    var heroSkill2Icon = node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('skill2').getChildByName('empty-skill');
                    var heroSkill1Name = node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('skill1').getChildByName('skill-name');
                    var heroSkill2Name = node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('skill2').getChildByName('skill-name');
                    var heroChangeName = node.getChildByName('player-2').getChildByName('hero-skillbar').getChildByName('changeBtn').getChildByName('label');
                    var url1 = cc.url.raw(currentHero.skill[0].icon);
                    var url2 = cc.url.raw(currentHero.skill[1].icon);
                    var img1 = cc.textureCache.addImage(url1);
                    var img2 = cc.textureCache.addImage(url2);
                    heroSkill1Icon.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(img1);
                    heroSkill2Icon.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(img2);
                    heroSkill1Name.getComponent(cc.Label).string = currentHero.skill[0].name;
                    heroSkill2Name.getComponent(cc.Label).string = currentHero.skill[1].name;
                    heroChangeName.getComponent(cc.Label).string = currentHero.skill[2].name;
                }
            }
        });
    }
});