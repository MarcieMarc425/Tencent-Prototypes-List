window['Global'] = {
    player1Status: [],
    player2Status: [],
    animStatus: null,
    animQueue: []
}