// var server = require('http').createServer();
// var io = require('socket.io')(server);
// io.on('connection', function(client){
//     console.log(client, 'fasfafas')
//   client.on('event', function(data){});
//   client.on('disconnect', function(){});
// });
// server.listen(3000, function() {
//     console.log('hello world');
// });

  const express = require('express');
  const WebSocket = require('ws');
  const http = require('http');

  const app = express();

  const server = http.createServer(app);
  const wss = new WebSocket.Server({ server });

  // var MongoClient = require('mongodb').MongoClient;

  // MongoClient.connect('mongodb://localhost:27017/player1-heroes', function (err, client) {
  //   if (err) throw err

  //   var db = client.db('player1-heroes');
    
  //   db.collection('availableHeroes').find({}).toArray(function (err, result) {
  //     if (err) throw err
  //     // for(var i = 0; i < result.length; i++) {
  //     //   console.log(result[i]);
  //     // }
  //     console.log(result[0].skill[0].name);
  //   })
  // })
// app.get('/', function (req, res) {
//   res.sendfile('./index.html');
// });


// let connections = {};

// wss.on('connection', function connection(ws, req) {
//   ws.on('message', function incoming(message) {
//       connection[open] = 
//     console.log(message);
//     ws.send('received: ' + message + '(From Server)');
//   });

//   ws.send('Hello Client');
// });

// server.listen(8080, function listening() {
//   console.log('Listening on %d', server.address().port);
// });