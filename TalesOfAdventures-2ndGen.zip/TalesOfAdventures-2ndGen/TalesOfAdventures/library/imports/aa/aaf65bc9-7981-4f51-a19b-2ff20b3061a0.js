"use strict";
cc._RF.push(module, 'aaf65vJeYFPUaGbL/ILMGGg', 'player2Controller');
// Script/player2Controller.js

'use strict';

// Learn cc.Class:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //     // ATTRIBUTES:
        //     default: null,        // The default value will be used only when the component attaching
        //                           // to a node for the first time
        //     type: cc.SpriteFrame, // optional, default is typeof default
        //     serializable: true,   // optional, default is true
        // },
        // bar: {
        //     get () {
        //         return this._bar;
        //     },
        //     set (value) {
        //         this._bar = value;
        //     }
        // },
        dmgLabelPrefab: {
            default: null,
            type: cc.Prefab
        }
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    registerStatus: function registerStatus() {
        this.isEffective = true;
        for (var i = 0; i < Global.player2Status.length; i++) {
            if (Global.player2Status[i].name == 'confused') {
                var random = Math.random() * 10;
                if (0 <= random && random < 3) this.isEffective = false;else this.isEffective = true;
            }
            if (Global.player2Status[i].name == 'burning' || Global.player2Status[i].name == 'bleeding') {
                var currentStatus = Global.player2Status[i];
                cc.loader.loadRes('json/player2-hero-list', function (err, heroList) {
                    if (heroList.current_fireteam[0].healthCurrent - currentStatus.dot <= 0) heroList.current_fireteam[0].healthCurrent = 0;else heroList.current_fireteam[0].healthCurrent -= currentStatus.dot;
                });
            }
        }
        var player2StatusNodes = this.node.parent.getChildByName('player-2').getChildByName('statusBar').getChildren();
        for (var i = 0; i < player2StatusNodes.length; i++) {
            player2StatusNodes[i].getComponent('statusIconTemplate').decrementCounter();
        }
        for (var i = 0; i < Global.player2Status.length; i++) {
            if (Global.player2Status[i].turn - 1 == 0) {
                Global.player2Status.splice(i, 1);
                i -= 1;
            } else Global.player2Status[i].turn -= 1;
        }
    },
    loadSkill: function loadSkill(skillType) {
        var node = this.node.parent;
        var self = this;
        var isEffective = this.isEffective;
        if (Global.player2Status.length != 0) cc.log(Global.player2Status[0]);
        cc.loader.loadRes('json/player2-hero-list', function (err, heroList) {
            var currentHero = heroList.current_fireteam[0];
            if (skillType == 'skill1' && isEffective) {
                if (currentHero.skill[0].name == '火球') {
                    var aniObj = new Object();
                    aniObj.player = 'player-2';
                    aniObj.name = 'fireball';
                    Global.animQueue.push(aniObj);
                    var aniObj2 = new Object();
                    aniObj2.player = 'player-1';
                    aniObj2.name = 'damage';
                    aniObj2.dps = currentHero.skill[0].dps;
                    Global.animQueue.push(aniObj2);
                    var type = currentHero.skill[0].type;
                    var dps = currentHero.skill[0].dps;
                    var status = currentHero.skill[0].status;
                    var turn = currentHero.skill[0].turn;
                    var dot = currentHero.skill[0].dot;
                    var url = currentHero.skill[0].statusUrl;
                    node.getChildByName('player1Controller').getComponent('player1Controller').registerP2Dmg(type, dps, status, turn, dot, url);
                }
                if (currentHero.skill[0].name == '背刺') {
                    var aniObj = new Object();
                    aniObj.player = 'player-2';
                    aniObj.name = 'melee';
                    Global.animQueue.push(aniObj);
                    var aniObj2 = new Object();
                    aniObj2.player = 'player-1';
                    aniObj2.name = 'damage';
                    var random = Math.random() * 10;
                    if (0 <= random && random < 0.5) var dps = 0;else if (0.5 <= random && random < 9) var dps = currentHero.skill[0].dps;else if (9 <= random && random < 10) var dps = 10;
                    aniObj2.dps = dps;
                    Global.animQueue.push(aniObj2);
                    var type = currentHero.skill[0].type;
                    var status = currentHero.skill[0].status;
                    var turn = currentHero.skill[0].turn;
                    var dot = currentHero.skill[0].dot;
                    var url = currentHero.skill[0].statusUrl;
                    node.getChildByName('player1Controller').getComponent('player1Controller').registerP2Dmg(type, dps, status, turn, dot, url);
                }
                if (currentHero.skill[0].name == '冲击') {
                    var aniObj = new Object();
                    aniObj.player = 'player-2';
                    aniObj.name = 'melee';
                    Global.animQueue.push(aniObj);
                    var aniObj2 = new Object();
                    aniObj2.player = 'player-1';
                    aniObj2.name = 'damage';
                    aniObj2.dps = currentHero.skill[0].dps;
                    Global.animQueue.push(aniObj2);
                    var aniObj3 = new Object();
                    aniObj3.player = 'player-2';
                    aniObj3.name = 'damage';
                    aniObj3.dps = currentHero.skill[0].selfdps;
                    Global.animQueue.push(aniObj3);
                    var type = currentHero.skill[0].type;
                    var dps = currentHero.skill[0].dps;
                    var status = currentHero.skill[0].status;
                    var turn = currentHero.skill[0].turn;
                    var dot = currentHero.skill[0].dot;
                    var url = currentHero.skill[0].statusUrl;
                    var selfDps = currentHero.skill[0].selfdps;
                    node.getChildByName('player1Controller').getComponent('player1Controller').registerP2Dmg(type, dps, status, turn, dot, url);
                    node.getChildByName('player2Controller').getComponent('player2Controller').registerP1Dmg(null, selfDps, null, null, null, null);
                }
            }
            if (skillType == 'skill2' && isEffective) {
                if (currentHero.skill[1].name == '法阵') {
                    var aniObj = new Object();
                    aniObj.player = 'player-2';
                    aniObj.name = 'dotBuff';
                    Global.animQueue.push(aniObj);
                    var buffObj = new Object();
                    buffObj.type = currentHero.skill[1].type;
                    buffObj.dps = currentHero.skill[1].dps;
                    buffObj.status = currentHero.skill[1].status;
                    buffObj.turn = currentHero.skill[1].turn;
                    buffObj.dot = currentHero.skill[1].dot;
                    buffObj.url = currentHero.skill[1].statusUrl;
                    self.registerBuff(buffObj);
                    // node.getChildByName('player2Controller').getComponent('player2Controller').registerP1Dmg(type, dps, status, turn, dot, url);
                }
                if (currentHero.skill[1].name == '闪光') {
                    var aniObj = new Object();
                    aniObj.player = 'player-2';
                    aniObj.name = 'flashObj';
                    Global.animQueue.push(aniObj);
                    var aniObj2 = new Object();
                    aniObj2.player = 'player-2';
                    aniObj2.name = 'flash';
                    Global.animQueue.push(aniObj2);
                    var aniObj3 = new Object();
                    aniObj3.player = 'player-1';
                    aniObj3.name = 'debuff';
                    Global.animQueue.push(aniObj3);
                    var debuffObj = new Object();
                    debuffObj.type = currentHero.skill[1].type;
                    debuffObj.dps = currentHero.skill[1].dps;
                    debuffObj.status = currentHero.skill[1].status;
                    debuffObj.turn = currentHero.skill[1].turn;
                    debuffObj.dot = currentHero.skill[1].dot;
                    debuffObj.url = currentHero.skill[1].statusUrl;
                    node.getChildByName('player1Controller').getComponent('player1Controller').registerBuff(debuffObj);
                }
            }
            if (skillType == 'change' && isEffective) {
                if (currentHero.skill[2].name == '魔法力量') {
                    var buffObj = new Object();
                    buffObj.type = currentHero.skill[2].type;
                    buffObj.dps = currentHero.skill[2].dps;
                    buffObj.status = currentHero.skill[2].status;
                    buffObj.turn = currentHero.skill[2].turn;
                    buffObj.dot = currentHero.skill[2].dot;
                    buffObj.url = currentHero.skill[2].statusUrl;
                    self.registerBuff(buffObj);
                }
            }
        });
    },
    registerP1Dmg: function registerP1Dmg(type, dps, status, turn, dot, url) {
        var self = this;
        var node = this.node.parent;

        // If has dps, filter through shield status, register dps
        if (dps != null) {
            var dpsNum = dps;
            //filter through shield
            for (var i = 0; i < Global.player2Status.length; i++) {
                if (Global.player2Status[i].name == 'physShield') {
                    // phys attack meets phys shield. -50% dmg
                    if (type == 'phys') dpsNum *= 0.5;
                    // ele attack meets phys shield, 50% chance to -50%dmg
                    else {
                            var chance = Math.random() * 10;
                            if (chance < 5) dpsNum = dps * .5;
                        }
                } else if (Global.player2Status[i].name == 'eleShield') {
                    // ele attack meets ele shield. -50% dmg
                    if (type == 'ele') dpsNum *= 0.5;
                    // phys attack meets ele shield, 50% chance to -50%dmg
                    else {
                            var chance = Math.random() * 10;
                            if (chance < 5) dpsNum = dps * .5;
                        }
                }
            }

            //register dps
            //if hero health is smaller than dmg, set hero health to zero
            cc.loader.loadRes('json/player2-hero-list', function (err, heroList) {
                if (heroList.current_fireteam[0].healthCurrent - dpsNum <= 0) heroList.current_fireteam[0].healthCurrent = 0;else heroList.current_fireteam[0].healthCurrent -= dpsNum;
            });
        }

        // If has status, find same status in Global and add turn, or if can't find, addd new status to Global
        if (status != null) {
            var statusFound = false;
            for (var i = 0; i < Global.player2Status.length; i++) {
                if (Global.player2Status[i].name == status) {
                    Global.player2Status[i].turn += turn;
                    var iconNodes = node.getChildByName('player-2').getChildByName('statusBar').getChildren();
                    for (var j = 0; j < iconNodes.length; j++) {
                        if (iconNodes[j].getComponent('statusIconTemplate').getNodeName() == status) iconNodes[j].getComponent('statusIconTemplate').addCounter(turn);
                    }
                    statusFound = true;
                }
            }
            if (!statusFound) {
                var statusObj = new Object();
                // register status info to object
                statusObj.name = status;
                statusObj.turn = turn;
                statusObj.url = url;
                statusObj.dot = dot;
                // if status has dot, and the other player already has dotBuff, +dot, else register normal dot
                if (status == 'burning' || status == 'bleeding') {
                    var isDotBuffed = false;
                    for (var i = 0; i < Global.player1Status.length; i++) {
                        if (Global.player1Status[i].name == 'dotBuff') {
                            var buff = Global.player1Status[i].dot;
                            isDotBuffed = true;
                        }
                    }
                    if (isDotBuffed) statusObj.dot = dot + buff;
                }
                Global.player2Status.push(statusObj);
                node.getChildByName('playerStatusList').getComponent('playerStatusList').addStatus(statusObj, 'player-2');
            }
        }
    },
    registerBuff: function registerBuff(buffObject) {
        // If has status, find same status in Global and add turn, or if can't find, add new status to Global
        var node = this.node.parent;
        if (buffObject.status != null) {
            var statusFound = false;
            for (var i = 0; i < Global.player2Status.length; i++) {
                if (Global.player2Status[i].name == buffObject.status) {
                    Global.player2Status[i].turn += buffObject.turn;
                    var iconNodes = node.getChildByName('player-2').getChildByName('statusBar').getChildren();
                    for (var j = 0; j < iconNodes.length; j++) {
                        if (iconNodes[j].getComponent('statusIconTemplate').getNodeName() == buffObject.status) iconNodes[j].getComponent('statusIconTemplate').addCounter(buffObject.turn);
                    }
                    statusFound = true;
                }
            }
            if (!statusFound) {
                var statusObj = new Object();
                // register status info to object
                statusObj.name = buffObject.status;
                statusObj.turn = buffObject.turn;
                statusObj.url = buffObject.url;
                statusObj.dot = buffObject.dot;
                Global.player2Status.push(statusObj);
                if (buffObject.status == 'dotBuff' || buffObject.status == 'tempDotBuff') {
                    // If player2 already has dot dmg (burning, bleeding), add dot buff to dot dmg
                    for (var i = 0; i < Global.player1Status.length; i++) {
                        if (Global.player1Status[i].name == 'burning' || Global.player1Status[i].name == 'bleeding') Global.player1Status[i].dot += buffObject.dot;
                    }
                } else if (buffObject.status == 'confused') node.getChildByName('playerStatusList').getComponent('playerStatusList').addStatus(statusObj, 'player-2');
                if (buffObject.status == 'dotBuff') node.getChildByName('playerStatusList').getComponent('playerStatusList').addStatus(statusObj, 'player-2');
            }
        }
    },
    start: function start() {},
    onLoad: function onLoad() {
        // Set Interval Timer
        this.updateInterval = 0.15;
        this.updateTimer = 0;
    },
    update: function update(dt) {
        this.updateTimer += dt;
        if (this.updateTimer < this.updateInterval) {
            return;
        }
        this.updateTimer = 0;

        var node = this.node.parent;
        cc.loader.loadRes('json/player2-hero-list', function (err, heroList) {
            var heroObj = heroList.current_fireteam[0];
            if (heroObj.healthCurrent == 0) {
                heroList.current_fireteam.splice(0, 1);
                heroList.current_fireteam.push(heroObj);
                node.getChildByName('player2Controller').getComponent('player2Controller').switchOut();
            }
        });
    }
});

cc._RF.pop();