"use strict";
cc._RF.push(module, '76622nuEtBDPYpGgW6lv6St', 'global');
// Script/global.js

'use strict';

window['Global'] = {
    player1Status: [],
    player2Status: [],
    animStatus: null,
    animQueue: []
};

cc._RF.pop();