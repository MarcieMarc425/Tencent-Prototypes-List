(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/statusIconTemplate.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '6d652VdFZBNdKdV2gRp++0+', 'statusIconTemplate', __filename);
// Script/statusIconTemplate.js

'use strict';

// Learn cc.Class:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
        statusImg: {
            default: null,
            type: cc.Sprite
        },
        statusTurn: {
            default: null,
            type: cc.Label
        }
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        // Set Interval Timer
        this.updateInterval = 0.10;
        this.updateTimer = 0;
    },
    start: function start() {},
    init: function init(statusName, statusUrl, statusTurn, statusDot, player) {
        this.exist = true;
        this.statusName = statusName;
        this.counter = statusTurn;
        this.player = player;
        this.dot = statusDot;
        var url = cc.url.raw(statusUrl);
        var img = cc.textureCache.addImage(url);
        this.statusImg.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(img);
        if (statusDot != null) {
            if (statusName == 'burning' || statusName == 'bleeding') this.statusTurn.getComponent(cc.Label).string = '-' + statusDot + '/' + statusTurn + '回合';else this.statusTurn.getComponent(cc.Label).string = statusTurn + '回合';
        } else this.statusTurn.getComponent(cc.Label).string = statusTurn + '回合';
    },
    update: function update(dt) {

        this.updateTimer += dt;
        if (this.updateTimer < this.updateInterval) {
            return;
        }
        this.updateTimer = 0;

        var statusName = this.statusName;
        var statusTurn = this.statusTurn;
        var statusDot = this.dot;
        var player = this.player;

        var node = this.node;

        if (player == 'player-1') {
            for (var i = 0; i < Global.player1Status.length; i++) {
                if (Global.player1Status[i].name == statusName) {
                    var currentStatus = Global.player1Status[i];
                    if (currentStatus.turn > 0) {
                        if (statusDot != null) {
                            if (statusName == 'burning' || statusName == 'bleeding') statusTurn.getComponent(cc.Label).string = '-' + currentStatus.dot + '/' + currentStatus.turn + '回合';else statusTurn.getComponent(cc.Label).string = currentStatus.turn + '回合';
                        } else statusTurn.getComponent(cc.Label).string = currentStatus.turn + '回合';
                    }
                }
            }
            if (this.counter == 0) this.destroyNode();
        } else if (player == 'player-2') {
            for (var i = 0; i < Global.player2Status.length; i++) {
                if (Global.player2Status[i].name == statusName) {
                    var currentStatus = Global.player2Status[i];
                    if (currentStatus.turn > 0) {
                        if (statusDot != null) {
                            if (statusName == 'burning' || statusName == 'bleeding') statusTurn.getComponent(cc.Label).string = '-' + currentStatus.dot + '/' + currentStatus.turn + '回合';else statusTurn.getComponent(cc.Label).string = currentStatus.turn + '回合';
                        } else statusTurn.getComponent(cc.Label).string = currentStatus.turn + '回合';
                    }
                }
            }
            if (this.counter == 0) this.destroyNode();
        }
    },
    destroyNode: function destroyNode() {
        this.node.destroy();
    },
    decrementCounter: function decrementCounter() {
        this.counter--;
    },
    getNodeName: function getNodeName() {
        return this.statusName;
    },
    addCounter: function addCounter(counter) {
        this.counter += counter;
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=statusIconTemplate.js.map
        