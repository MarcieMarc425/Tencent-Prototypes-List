# Project Progress

## Finished:

    - Implement Battle UI

    - Implement databases for heroes of p1 and p2

    - Create resources for skills icon, status effects, skills desc.

    - Tweak Battle UI
        - Players should see clearly to 'choose a skill', 'readying', 'waiting for player x'
        - Omit battle button, progress from choosing skill -> confirmation
    
    - Fix status prefab bug
        - When adding turns to same status in player-x-currentStatus, the turns are registered in array, but prefab is still destroyed after initial counter
            - Need to add turn number to prefab counter when adding turns to same status

    - Implement animation chaining system
        - For example, if (change, skill1), should do change animation first, then skill1 animation

    - Enable player2 play

    - Implement animations and skills for all heroes
        - Hero 1 (Done)
        - Hero 2 (Done, need switch)
        - Hero 3 (Skill 1 Done, need skill2, switch)


## To do:

    - *Implement animations and skills for all heroes
        - Hero 4 ()
        - Hero 5
        - Hero 6
    
    - Burning status effect bug, when '1回合' and next turn adds 2, dmg refreshes

    - DotBuff skill effect bug, buff should only last during status effect

    - Update skill desc. (魔法力量，背刺，闪光)

    - When hero is dead and switching to next hero, hero model is not properly loaded

    - Add a battle report feature
        - Either players should be able to click on the battle report and see all actions from both players
            - ? Current status affecting either players
    
    - Implement basic heroes selection menu
