"use strict";
cc._RF.push(module, '038eae8MfRKv7fRwjlCyX38', 'main');
// main.js

"use strict";

// Learn cc.Class:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
        uncookedCounter: {
            default: null,
            type: cc.Label
        },
        connectionDisplay: {
            default: null,
            type: cc.Label
        },
        player1Count: {
            default: null,
            type: cc.Label
        },
        player2Count: {
            default: null,
            type: cc.Label
        },
        player1Money: {
            default: null,
            type: cc.Label
        },
        plusBtn: {
            default: null,
            type: cc.Button
        },
        minusBtn: {
            default: null,
            type: cc.Button
        },
        cookBtn: {
            default: null,
            type: cc.Button
        },
        buyBtn: {
            default: null,
            type: cc.Button
        }
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},
    onLoad: function onLoad() {
        this.uncooked = 0;
        this.uncookedCounter.string = this.uncooked;
    },
    start: function start() {},
    plusBtnOnClicked: function plusBtnOnClicked() {
        this.uncooked++;
    },
    minusBtnOnClicked: function minusBtnOnClicked() {
        if (this.uncooked - 1 < 0) return;else this.uncooked--;
    },
    cookBtnOnClicked: function cookBtnOnClicked() {},
    buyBtnOnClicked: function buyBtnOnClicked() {},
    update: function update(dt) {
        this.uncookedCounter.string = this.uncooked;
    }
    // update (dt) {},

});

cc._RF.pop();