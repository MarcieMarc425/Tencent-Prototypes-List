"use strict";
cc._RF.push(module, '1d1059vKm1F76+mHZJX/pLL', 'global');
// Script/global.js

'use strict';

window['global'] = {

    current_page: '',
    current_enemy_status_queue: [],
    intent: null
};

cc._RF.pop();