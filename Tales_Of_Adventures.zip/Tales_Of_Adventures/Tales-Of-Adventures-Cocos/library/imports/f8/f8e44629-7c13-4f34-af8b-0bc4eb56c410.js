"use strict";
cc._RF.push(module, 'f8e44YpfBNPNK+LC8TrVsQQ', 'HeroItemTemplate');
// Script/HeroItemTemplate.js

'use strict';

// Learn cc.Class:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
        heroID: 0,
        heroImage: {
            default: null,
            type: cc.Sprite
        },
        heroName: {
            default: null,
            type: cc.Label
        },
        heroLevel: {
            default: null,
            type: cc.Label
        },
        heroCost: {
            default: null,
            type: cc.Label
        },
        button: {
            default: null,
            type: cc.Button
        }
    },

    // LIFE-CYCLE CALLBACKS:

    init: function init(heroID, heroName, heroLevel, heroImg, heroCost, isBought) {
        this.heroID = heroID;
        this.heroName.getComponent(cc.Label).string = heroName;
        this.heroLevel.getComponent(cc.Label).string = 'LVL.' + heroLevel;
        this.heroCost.getComponent(cc.Label).string = '$' + heroCost;
        var url = cc.url.raw(heroImg);
        var texture = cc.textureCache.addImage(url);
        this.heroImage.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(texture);
        if (isBought) {
            this.heroCost.node.active = false;
        } else {
            this.heroCost.node.active = true;
        }
    },

    onLoad: function onLoad() {},
    start: function start() {},


    onClick: function onClick() {
        var heroID = this.heroID;
        var heroControl = this.node.getParent().getParent().getParent().getParent().getParent();
        var heroSelect = this.node.getParent();
        var currPage = heroControl.getChildByName('heroWindow').getChildByName('view').getChildByName('content').getChildByName(global.current_page);
        var prevID = currPage.heroID;
        cc.loader.loadRes('hero-info', function (err, heroList) {
            var heroObject = new Object();
            for (var i = 0; i < heroList.current_fireteam.length; i++) {
                if (heroList.current_fireteam[i].heroID == prevID) {
                    heroObject = heroList.current_fireteam[i];
                    heroList.available_fireteam.push(heroObject);
                    heroList.current_fireteam.splice(i, 1);
                    heroSelect.getComponent('HeroSelectionList').addAnIcon(heroObject);
                }
            }
            for (var i = 0; i < heroList.available_fireteam.length; i++) {
                if (heroList.available_fireteam[i].heroID == heroID) {
                    heroObject = heroList.available_fireteam[i];
                    heroList.current_fireteam.push(heroObject);
                    heroList.available_fireteam.splice(i, 1);
                    currPage.heroID = heroID;
                }
            }
            for (var i = 0; i < heroList.unlocked_fireteam.length; i++) {
                if (heroList.unlocked_fireteam[i].heroID == heroID) {
                    heroObject = heroList.unlocked_fireteam[i];
                    heroList.current_fireteam.push(heroObject);
                    heroList.unlocked_fireteam.splice(i, 1);
                    currPage.heroID = heroID;
                }
            }
        });

        currPage.status = 'occupied';
        this.node.destroy();
    }

    // update (dt) {},
});

cc._RF.pop();