(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/enemyController.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '3b81dicvGxKbpvDFqYv3HeQ', 'enemyController', __filename);
// Script/enemyController.js

'use strict';

// Learn cc.Class:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //     // ATTRIBUTES:
        //     default: null,        // The default value will be used only when the component attaching
        //                           // to a node for the first time
        //     type: cc.SpriteFrame, // optional, default is typeof default
        //     serializable: true,   // optional, default is true
        // },
        // bar: {
        //     get () {
        //         return this._bar;
        //     },
        //     set (value) {
        //         this._bar = value;
        //     }
        // },
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    onLoad: function onLoad() {
        this.updateInterval = 0.15;
        this.updateTimer = 0;
    },
    start: function start() {},


    setIntent: function setIntent() {

        var enemyNode = this.node.parent.getChildByName('enemy');

        cc.loader.loadRes('enemy-info', function (err, enemyInfo) {
            var dice = Math.random() * 10;
            for (var i = 0; i < enemyInfo.enemy1.attack_pattern.length; i++) {
                var chanceMin = enemyInfo.enemy1.attack_pattern[i].min;
                var chanceMax = enemyInfo.enemy1.attack_pattern[i].max;
                if (dice >= chanceMin && dice < chanceMax) {
                    var type = enemyInfo.enemy1.attack_pattern[i].type;
                    if (type == 'normal') {
                        enemyNode.getChildByName('enemy-intent').getChildByName('attack-intent').active = true;
                        enemyNode.getChildByName('enemy-intent').getChildByName('block-intent').active = false;
                        enemyNode.getChildByName('enemy-intent').getChildByName('buff-intent').active = false;
                        enemyNode.getChildByName('enemy-intent').getChildByName('debuff-intent').active = false;
                        global.intent = 'normal';
                    } else if (type == 'block') {
                        enemyNode.getChildByName('enemy-intent').getChildByName('attack-intent').active = false;
                        enemyNode.getChildByName('enemy-intent').getChildByName('block-intent').active = true;
                        enemyNode.getChildByName('enemy-intent').getChildByName('buff-intent').active = false;
                        enemyNode.getChildByName('enemy-intent').getChildByName('debuff-intent').active = false;
                        global.intent = 'block';
                    } else if (type == 'buff') {
                        enemyNode.getChildByName('enemy-intent').getChildByName('attack-intent').active = false;
                        enemyNode.getChildByName('enemy-intent').getChildByName('block-intent').active = false;
                        enemyNode.getChildByName('enemy-intent').getChildByName('buff-intent').active = true;
                        enemyNode.getChildByName('enemy-intent').getChildByName('debuff-intent').active = false;
                        global.intent = 'buff';
                    } else if (type == 'debuff') {
                        enemyNode.getChildByName('enemy-intent').getChildByName('attack-intent').active = false;
                        enemyNode.getChildByName('enemy-intent').getChildByName('block-intent').active = false;
                        enemyNode.getChildByName('enemy-intent').getChildByName('buff-intent').active = false;
                        enemyNode.getChildByName('enemy-intent').getChildByName('debuff-intent').active = true;
                        global.intent = 'debuff';
                    }
                }
            }
        });
    },

    registerDmg: function registerDmg(value, condition, turn, url) {
        var node = this.node.parent;
        var condition = condition;
        var turn = turn;
        if (value != null) {
            if (condition == null) {
                cc.loader.loadRes('enemy-info', function (err, enemyInfo) {
                    if (enemyInfo.enemy1.block.current - value <= 0) {
                        enemyInfo.enemy1.health.current = enemyInfo.enemy1.health.current - (value - enemyInfo.enemy1.block.current);
                        enemyInfo.enemy1.block.current = 0;
                    } else enemyInfo.enemy1.block.current = enemyInfo.enemy1.block.current - value;
                });
            } else {
                var flag = false;
                cc.loader.loadRes('enemy-info', function (err, enemyInfo) {
                    if (enemyInfo.enemy1.current_status.length == 0) {
                        var status = new Object();
                        status.condition = condition;
                        status.turn = turn;
                        status.url = url;
                        enemyInfo.enemy1.current_status.push(status);
                        node.getChildByName('enemy').getChildByName('enemy-status-bar').getComponent('enemyStatusList').addStatus(status);
                    } else {
                        for (var i = 0; i < enemyInfo.enemy1.current_status.length; i++) {
                            if (!flag) {
                                if (condition == enemyInfo.enemy1.current_status[i].condition) {
                                    enemyInfo.enemy1.current_status[i].turn = enemyInfo.enemy1.current_status[i].turn + turn;
                                    flag = true;
                                }
                            }
                        }
                        if (!flag) {
                            var status = new Object();
                            var node = this.node.parent;
                            status.condition = condition;
                            status.turn = turn;
                            status.url = url;
                            enemyInfo.enemy1.current_status.push(status);
                            node.getChildByName('enemy').getChildByName('enemy-status-bar').getComponent('enemyStatusList').addStatus(status);
                        }
                    }
                    if (enemyInfo.enemy1.block.current - value <= 0) {
                        enemyInfo.enemy1.health.current = enemyInfo.enemy1.health.current - (value - enemyInfo.enemy1.block.current);
                        enemyInfo.enemy1.block.current = 0;
                    } else enemyInfo.enemy1.block.current = enemyInfo.enemy1.block.current - value;
                });
            }
        } else {

            cc.loader.loadRes('enemy-info', function (err, enemyInfo) {
                if (enemyInfo.enemy1.current_status.length == 0) {
                    var status = new Object();
                    status.condition = condition;
                    status.turn = turn;
                    status.url = url;
                    enemyInfo.enemy1.current_status.push(status);
                    node.getChildByName('enemy').getChildByName('enemy-status-bar').getComponent('enemyStatusList').addStatus(status);
                } else {
                    for (var i = 0; i < enemyInfo.enemy1.current_status.length; i++) {
                        if (!flag) {
                            if (condition == enemyInfo.enemy1.current_status[i].condition) {
                                enemyInfo.enemy1.current_status[i].turn = enemyInfo.enemy1.current_status[i].turn + turn;
                                flag = true;
                            }
                        }
                    }
                    if (!flag) {
                        var status = new Object();
                        status.condition = condition;
                        status.turn = turn;
                        status.url = url;
                        enemyInfo.enemy1.current_status.push(status);
                        node.getChildByName('enemy').getChildByName('enemy-status-bar').getComponent('enemyStatusList').addStatus(status);
                    }
                }
            });
        }
        cc.loader.loadRes('enemy-info', function (err, enemyInfo) {
            cc.log(enemyInfo.enemy1);
        });
    },

    registerPassThrough: function registerPassThrough(value) {
        cc.loader.loadRes('enemy-info', function (err, enemyInfo) {
            if (enemyInfo.enemy1.health.current - value <= 0) enemyInfo.enemy1.health.current = 0;else enemyInfo.enemy1.health.current = enemyInfo.enemy1.health.current - value;
        });
    },

    registerDmgShield: function registerDmgShield(value) {
        cc.loader.loadRes('enemy-info', function (err, enemyInfo) {
            if (enemyInfo.enemy1.block.current - value <= 0) enemyInfo.enemy1.block.current = 0;else enemyInfo.enemy1.block.current = enemy1.enemy1.block.current - value;
        });
    },

    registerStatusEffect: function registerStatusEffect() {
        cc.loader.loadRes('enemy-info', function (err, enemyInfo) {
            for (var i = 0; i < enemyInfo.enemy1.current_status.length; i++) {
                var status = enemyInfo.enemy1.current_status[i];
                if (status.condition == 'burning') {
                    if (enemyInfo.enemy1.health.current - 3 <= 0) enemyInfo.enemy1.health.current = 0;else enemyInfo.enemy1.health.current = enemyInfo.enemy1.health.current - 3;
                } else if (status.condition == 'bleeding') {
                    if (enemyInfo.enemy1.health.current - 7 <= 0) enemyInfo.enemy1.health.current = 0;else enemyInfo.enemy1.health.current = enemyInfo.enemy1.health.current - 7;
                } else if (status.condition == 'confusion') {}
                if (status.turn - 1 == 0) {
                    enemyInfo.enemy1.current_status.splice(i, 1);
                    i = i - 1;
                } else status.turn = status.turn - 1;
            }
        });
    },

    // update (dt) {},

    update: function update(dt) {

        var enemyNode = this.node.parent.getChildByName('enemy');

        this.updateTimer += dt;
        if (this.updateTimer < this.updateInterval) {
            return;
        }
        this.updateTimer = 0;

        cc.loader.loadRes('enemy-info', function (err, enemyInfo) {
            if (enemyInfo.enemy1.block.current > 0) {
                enemyNode.getChildByName('enemy-shield').active = true;
                enemyNode.getChildByName('enemy-shield').getChildByName('shield-value').getComponent(cc.Label).string = enemyInfo.enemy1.block.current;
            } else {
                enemyNode.getChildByName('enemy-shield').active = false;
                enemyNode.getChildByName('enemy-shield').getChildByName('shield-value').getComponent(cc.Label).string = enemyInfo.enemy1.block.current;
            }
            enemyNode.getChildByName('enemy-health').getComponent(cc.Label).string = enemyInfo.enemy1.health.current + '/' + enemyInfo.enemy1.health.total;
            enemyNode.getChildByName('enemy-health-progress').getComponent(cc.ProgressBar).progress = enemyInfo.enemy1.health.current / enemyInfo.enemy1.health.total;

            if (enemyInfo.enemy1.health.current <= 0) {
                cc.director.loadScene('Main View');
            }
        });
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=enemyController.js.map
        