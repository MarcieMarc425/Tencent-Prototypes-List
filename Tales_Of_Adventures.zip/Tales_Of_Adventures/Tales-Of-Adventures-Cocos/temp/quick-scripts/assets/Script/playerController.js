(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/playerController.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '2be9cheEepAKJxPodzgAfAe', 'playerController', __filename);
// Script/playerController.js

'use strict';

// Learn cc.Class:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //     // ATTRIBUTES:
        //     default: null,        // The default value will be used only when the component attaching
        //                           // to a node for the first time
        //     type: cc.SpriteFrame, // optional, default is typeof default
        //     serializable: true,   // optional, default is true
        // },
        // bar: {
        //     get () {
        //         return this._bar;
        //     },
        //     set (value) {
        //         this._bar = value;
        //     }
        // },
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},
    onLoad: function onLoad() {
        this.updateInterval = 0.15;
        this.updateTimer = 0;

        this.block = 0;
    },
    start: function start() {},


    update: function update(dt) {

        this.updateTimer += dt;
        if (this.updateTimer < this.updateInterval) {
            return;
        }
        this.updateTimer = 0;
        var blockValue = this.block;

        var node = this.node.parent.getChildByName('heroInfoBar');
        cc.loader.loadRes('hero-info', function (err, heroList) {
            for (var i = 0; i < 3; i++) {
                var page = 'hero-';
                var currNode = page + (i + 1);
                node.getChildByName(currNode).getChildByName('health').getComponent(cc.Label).string = heroList.current_fireteam[i].health.current + '/';
                node.getChildByName(currNode).getChildByName('cp').getComponent(cc.Label).string = heroList.current_fireteam[i].cp.current;
            }
            node.parent.getChildByName('hero-status').getChildByName('shield-value').getComponent(cc.Label).string = blockValue;
        });
    },

    setBlock: function setBlock(value) {
        this.block = value;
    }

    // update (dt) {},
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=playerController.js.map
        