// Learn cc.Class:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //     // ATTRIBUTES:
        //     default: null,        // The default value will be used only when the component attaching
        //                           // to a node for the first time
        //     type: cc.SpriteFrame, // optional, default is typeof default
        //     serializable: true,   // optional, default is true
        // },
        // bar: {
        //     get () {
        //         return this._bar;
        //     },
        //     set (value) {
        //         this._bar = value;
        //     }
        // },
        heroControl: {
            default: null,
            type: cc.Node
        },

        heroWindow: {
            default: null,
            type: cc.PageView
        },

        heroName: {
            default: null,
            type: cc.Label
        },

        healthBar: {
            default: null,
            type: cc.ProgressBar
        },

        cpBar: {
            default: null,
            type: cc.ProgressBar
        },

        expBar: {
            default: null,
            type: cc.ProgressBar
        }
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    onLoad() {

        // Setup Update Timers
        this.updateInterval = 0.15;
        this.updateTimer = 0;

        var currentPage = 'page_';
        var status = this.heroWindow.node.getChildByName('view').getChildByName('content');
        var name = this.heroName;
        var health = this.healthBar;
        var cp = this.cpBar;
        var exp = this.expBar;
        var currentNum;

        // Setup blank page
        this.heroControl.getChildByName('hero-name').active = false;
        this.heroControl.getChildByName('Sidebar').active = false;
        this.heroControl.getChildByName('Status Bar').active = false;
        this.heroControl.getChildByName('heroSelection').active = false;

        cc.loader.loadRes('hero-info', function(err, heroList) {
            currentNum = heroList.current_fireteam.length;
            for (let i = 0; i < heroList.current_fireteam.length; i++) {
                currentPage = currentPage + (i+1);
                var currentHero = heroList.current_fireteam[i];
                var currentHeroPage = status.getChildByName(currentPage);
                currentHeroPage.heroID = currentHero.heroID;
                currentHeroPage.getChildByName('hero-lvl').getComponent(cc.Label).string = 'LVL.'+ currentHero.level;
                currentHeroPage.getChildByName('hero-portrait').getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(cc.textureCache.addImage(cc.url.raw(currentHero.img)));
                currentHeroPage.getChildByName('hero-portrait').active = true;
                currentHeroPage.getChildByName('hero-lvl').active = true;
                currentHeroPage.getChildByName('heroCreate-btn').active = false;    
                currentHeroPage.status = 'occupied';
                currentPage = 'page_';
            }
            if (currentNum > 0){
                var firstHero = heroList.current_fireteam[0];
                name.getComponent(cc.Label).string = firstHero.name;
                health.getComponent(cc.ProgressBar).progress = firstHero.health.current/firstHero.health.total;
                cp.getComponent(cc.ProgressBar).progress = firstHero.cp.current/firstHero.cp.total;
                exp.getComponent(cc.ProgressBar).progress = firstHero.exp.current/firstHero.exp.total;
            }
            for (let i = currentNum; i < 3; i++) {
                currentPage = currentPage + (i+1);
                status.getChildByName(currentPage).status = 'empty';
                status.getChildByName(currentPage).getChildByName('hero-lvl').active = false;
                status.getChildByName(currentPage).getChildByName('hero-portrait').active = false;
                status.getChildByName(currentPage).getChildByName('heroCreate-btn').active = true;
                currentPage = 'page_';
            }
        });
    },

    start () {

    },

    update(dt) {
        this.updateTimer += dt;
        if (this.updateTimer < this.updateInterval){
            return; 
        }
        this.updateTimer = 0;

        var currentPageIndex = this.heroWindow.getCurrentPageIndex();
        var currentPage = 'page_'+(currentPageIndex+1);
        global.current_page = currentPage;
        var currentPageNode = this.heroWindow.node.getChildByName('view').getChildByName('content').getChildByName(currentPage);
        var status = currentPageNode.status;
        var name = this.heroName;
        var health = this.healthBar;
        var cp = this.cpBar;
        var exp = this.expBar;
        if (status == 'occupied'){
            currentPageNode.getChildByName('hero-portrait').active = true;
            currentPageNode.getChildByName('hero-lvl').active = true;
            currentPageNode.getChildByName('heroCreate-btn').active = false;
            cc.loader.loadRes('hero-info', function(err, heroList) {
                var currentHeroID = currentPageNode.heroID;
                // var currentHero = heroList.current_fireteam[currentPageIndex];
                for(var i = 0; i < heroList.current_fireteam.length; i++){
                    if(currentHeroID == heroList.current_fireteam[i].heroID){
                        var currentHero = heroList.current_fireteam[i];
                        currentPageNode.getChildByName('hero-portrait').getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(cc.textureCache.addImage(cc.url.raw(currentHero.img)));
                        name.getComponent(cc.Label).string = currentHero.name;
                        health.getComponent(cc.ProgressBar).progress = currentHero.health.current/currentHero.health.total;
                        cp.getComponent(cc.ProgressBar).progress = currentHero.cp.current/currentHero.cp.total;
                        exp.getComponent(cc.ProgressBar).progress = currentHero.exp.current/currentHero.exp.total;        
                    }
                }
            });
            this.heroControl.getChildByName('hero-name').active = true;
            this.heroWindow.node.getChildByName('indicator').active = true;
            this.heroControl.getChildByName('Sidebar').active = true;
            this.heroControl.getChildByName('Status Bar').active = true;
            this.heroControl.getChildByName('heroSelection').active = false;
        } else if (status == 'empty') {
            currentPageNode.getChildByName('hero-portrait').active = false;
            currentPageNode.getChildByName('hero-lvl').active = false;
            currentPageNode.getChildByName('heroCreate-btn').active = true;
            this.heroWindow.node.getChildByName('indicator').active = true;

            this.heroControl.getChildByName('hero-name').active = false;
            this.heroControl.getChildByName('Sidebar').active = false;
            this.heroControl.getChildByName('Status Bar').active = false;
            this.heroControl.getChildByName('heroSelection').active = false;
        } else if (status == 'heroSelecting') {
            currentPageNode.getChildByName('hero-portrait').active = false;
            currentPageNode.getChildByName('hero-lvl').active = false;
            currentPageNode.getChildByName('heroCreate-btn').active = false;
            this.heroWindow.node.getChildByName('indicator').active = false;

            this.heroControl.getChildByName('hero-name').active = false;
            this.heroControl.getChildByName('Sidebar').active = false;
            this.heroControl.getChildByName('Status Bar').active = false;
            this.heroControl.getChildByName('heroSelection').active = true;
        }
    },

    createButton: function() {
        var currentPageIndex = this.heroWindow.getCurrentPageIndex();
        var currentPage = 'page_' + (currentPageIndex+1);
        var currentPageNode = this.heroWindow.node.getChildByName('view').getChildByName('content').getChildByName(currentPage);
        currentPageNode.prevStatus = 'empty';
        currentPageNode.status = 'heroSelecting';
    },

    backButton: function() {
        var currentPageIndex = this.heroWindow.getCurrentPageIndex();
        var currentPage = 'page_' + (currentPageIndex+1);
        var currentPageNode = this.heroWindow.node.getChildByName('view').getChildByName('content').getChildByName(currentPage);
        var status = currentPageNode.prevStatus;
        if(status == 'empty')
            currentPageNode.status = 'empty';
        else if(status == 'occupied')
            currentPageNode.status = 'occupied';
    },

    changeHeroBtn: function() {
        var currentPageIndex = this.heroWindow.getCurrentPageIndex();
        var currentPage = 'page_' + (currentPageIndex+1);
        var currentPageNode = this.heroWindow.node.getChildByName('view').getChildByName('content').getChildByName(currentPage);
        currentPageNode.prevStatus = 'occupied';
        currentPageNode.status = 'heroSelecting';
        
    },

    loadHeroScreen: function() {
        cc.director.loadScene('Main View');
    },

    loadBattleScreen: function() {
        cc.loader.loadRes('hero-info', function(err, heroList) {
            cc.log(heroList.current_fireteam.length);
            if(heroList.current_fireteam.length == 3){
                cc.director.loadScene('Battle View');
            }
        });
    }


});
