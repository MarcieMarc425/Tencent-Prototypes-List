// Learn cc.Class:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
        hero1_portrait: {
            default: null,
            type: cc.Sprite
        },
        hero2_portrait: {
            default: null,
            type: cc.Sprite
        },
        hero3_portrait: {
            default: null,
            type: cc.Sprite
        }
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    onLoad() {

        this.updateInterval = 0.15;
        this.updateTimer = 0;

        this.turn = 'player';
        this.turn1 = true;

        var hero1_icon = this.hero1_portrait;
        var hero2_icon = this.hero2_portrait;
        var hero3_icon = this.hero3_portrait;
        var node = this.node.parent;

        node.getChildByName('enemyController').getComponent('enemyController').setIntent();

        node.getChildByName('hero-status').getChildByName('shield-value').getComponent(cc.Label).string = 0;

        cc.loader.loadRes('hero-info', function(err, heroList) {
            var url = cc.url.raw(heroList.current_fireteam[0].icon);
            var texture = cc.textureCache.addImage(url);
            hero1_icon.spriteFrame = new cc.SpriteFrame(texture);
        
            var url = cc.url.raw(heroList.current_fireteam[1].icon);
            var texture = cc.textureCache.addImage(url);
            hero2_icon.spriteFrame = new cc.SpriteFrame(texture);

            var url = cc.url.raw(heroList.current_fireteam[2].icon);
            var texture = cc.textureCache.addImage(url);
            hero3_icon.spriteFrame = new cc.SpriteFrame(texture);

            for(var i = 0; i < 3; i++) {
                var pageName = 'hero-' + (i+1);
                node.getChildByName('heroInfoBar').getChildByName(pageName).heroID = heroList.current_fireteam[i].heroID;
                node.getChildByName('heroInfoBar').getChildByName(pageName).supportSkill = heroList.current_fireteam[i].combat.support;
                node.getChildByName('heroInfoBar').getChildByName(pageName).attackSkill = heroList.current_fireteam[i].combat.attack;
                node.getChildByName('heroInfoBar').getChildByName(pageName).defenseSkill = heroList.current_fireteam[i].combat.defense;

                var health = node.getChildByName('heroInfoBar').getChildByName(pageName).getChildByName('health');
                var cp = node.getChildByName('heroInfoBar').getChildByName(pageName).getChildByName('cp');
                health.getComponent(cc.Label).string = heroList.current_fireteam[i].health.current + '/';
                cp.getComponent(cc.Label).string = heroList.current_fireteam[i].cp.current;
            }
        });

        node.getChildByName('skillBar').active = false;

        node.selectedSupp = ['empty', 'empty'];
        node.selectedAttk = ['empty', 'empty'];
        node.selectedDef = ['empty', 'empty'];

        cc.loader.loadRes('enemy-info', function(err, enemyList) {
            node.getChildByName('enemy').getChildByName('enemy-health').getComponent(cc.Label).string = enemyList.enemy1.health.current + '/' + enemyList.enemy1.health.total;
        });
    },

    start () {

    },

    hero1_onClick: function() {
        var node = this.node.parent;
        node.getChildByName('skillBar').active = true;
        node.heroSelected = node.getChildByName('heroInfoBar').getChildByName('hero-1').heroID;
        node.supportSkill = node.getChildByName('heroInfoBar').getChildByName('hero-1').supportSkill;
        node.attackSkill = node.getChildByName('heroInfoBar').getChildByName('hero-1').attackSkill;
        node.defenseSkill = node.getChildByName('heroInfoBar').getChildByName('hero-1').defenseSkill;
        cc.loader.loadRes('skill-info', function(err, skillList) {
            for(var i = 0; i < skillList.skillImg.length; i++) {
                if(skillList.skillImg[i].skillID == node.supportSkill){
                    var url = cc.url.raw(skillList.skillImg[i].img);
                    var image = cc.textureCache.addImage(url);
                    node.getChildByName('skillBar').getChildByName('suppBtn-empty').getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(image);
                } else if(skillList.skillImg[i].skillID == node.attackSkill) {
                    var url = cc.url.raw(skillList.skillImg[i].img);
                    var image = cc.textureCache.addImage(url);
                    node.getChildByName('skillBar').getChildByName('attkBtn-empty').getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(image);

                } else if (skillList.skillImg[i].skillID == node.defenseSkill) {
                    var url = cc.url.raw(skillList.skillImg[i].img);
                    var image = cc.textureCache.addImage(url);
                    node.getChildByName('skillBar').getChildByName('defBtn-empty').getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(image);
                } 
            }
        });
    },

    hero2_onClick: function() {
        var node = this.node.parent;
        node.getChildByName('skillBar').active = true;
        node.heroSelected = node.getChildByName('heroInfoBar').getChildByName('hero-2').heroID;
        node.supportSkill = node.getChildByName('heroInfoBar').getChildByName('hero-2').supportSkill;
        node.attackSkill = node.getChildByName('heroInfoBar').getChildByName('hero-2').attackSkill;
        node.defenseSkill = node.getChildByName('heroInfoBar').getChildByName('hero-2').defenseSkill;
        cc.loader.loadRes('skill-info', function(err, skillList) {
            for(var i = 0; i < skillList.skillImg.length; i++) {
                if(skillList.skillImg[i].skillID == node.supportSkill){
                    var url = cc.url.raw(skillList.skillImg[i].img);
                    var image = cc.textureCache.addImage(url);
                    node.getChildByName('skillBar').getChildByName('suppBtn-empty').getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(image);
                } else if(skillList.skillImg[i].skillID == node.attackSkill) {
                    var url = cc.url.raw(skillList.skillImg[i].img);
                    var image = cc.textureCache.addImage(url);
                    node.getChildByName('skillBar').getChildByName('attkBtn-empty').getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(image);

                } else if (skillList.skillImg[i].skillID == node.defenseSkill) {
                    var url = cc.url.raw(skillList.skillImg[i].img);
                    var image = cc.textureCache.addImage(url);
                    node.getChildByName('skillBar').getChildByName('defBtn-empty').getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(image);
                } 
            }
        });
    },

    hero3_onClick: function() {
        var node = this.node.parent;
        node.getChildByName('skillBar').active = true;
        node.heroSelected = node.getChildByName('heroInfoBar').getChildByName('hero-3').heroID;
        node.supportSkill = node.getChildByName('heroInfoBar').getChildByName('hero-3').supportSkill;
        node.attackSkill = node.getChildByName('heroInfoBar').getChildByName('hero-3').attackSkill;
        node.defenseSkill = node.getChildByName('heroInfoBar').getChildByName('hero-3').defenseSkill;
        cc.loader.loadRes('skill-info', function(err, skillList) {
            for(var i = 0; i < skillList.skillImg.length; i++) {
                if(skillList.skillImg[i].skillID == node.supportSkill){
                    var url = cc.url.raw(skillList.skillImg[i].img);
                    var image = cc.textureCache.addImage(url);
                    node.getChildByName('skillBar').getChildByName('suppBtn-empty').getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(image);
                } else if(skillList.skillImg[i].skillID == node.attackSkill) {
                    var url = cc.url.raw(skillList.skillImg[i].img);
                    var image = cc.textureCache.addImage(url);
                    node.getChildByName('skillBar').getChildByName('attkBtn-empty').getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(image);

                } else if (skillList.skillImg[i].skillID == node.defenseSkill) {
                    var url = cc.url.raw(skillList.skillImg[i].img);
                    var image = cc.textureCache.addImage(url);
                    node.getChildByName('skillBar').getChildByName('defBtn-empty').getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(image);
                } 
            }
        });
    },

    suppSkill_onClick: function() {
        var node = this.node.parent;
        if(node.selectedAttk[0] == node.heroSelected){
            node.selectedAttk[0] = 'empty';
            node.selectedAttk[1] = 'empty';
            var url = cc.url.raw('resources/mini-hero/mini-hero-empty.png');
            var image = cc.textureCache.addImage(url);
            node.getChildByName('hero-order').getChildByName('attkSkill').getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(image);
        } else if (node.selectedDef[0] == node.heroSelected) {
            node.selectedDef[0] = 'empty';
            node.selectedDef[1] = 'empty';
            var url = cc.url.raw('resources/mini-hero/mini-hero-empty.png');
            var image = cc.textureCache.addImage(url);
            node.getChildByName('hero-order').getChildByName('defSkill').getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(image);
        }
        node.selectedSupp[0] = node.heroSelected;
        node.selectedSupp[1] = node.supportSkill;
        cc.loader.loadRes('hero-info', function(err, heroList) {
            for(var i = 0; i < heroList.current_fireteam.length; i++) {
                if(heroList.current_fireteam[i].heroID == node.heroSelected) {
                    var url = cc.url.raw(heroList.current_fireteam[i].icon);
                    var image = cc.textureCache.addImage(url);
                    node.getChildByName('hero-order').getChildByName('suppSkill').getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(image);
                }
            }
        });
    },

    attkSkill_onClick: function() {
        var node = this.node.parent;
        if(node.selectedSupp[0] == node.heroSelected) {
            node.selectedSupp[0] = 'empty';
            node.selectedSupp[1] = 'empty';
            var url = cc.url.raw('resources/mini-hero/mini-hero-empty.png');
            var image = cc.textureCache.addImage(url);
            node.getChildByName('hero-order').getChildByName('suppSkill').getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(image);
        } else if (node.selectedDef[0] == node.heroSelected) {
            node.selectedDef[0] = 'empty';
            node.selectedDef[1] = 'empty';
            var url = cc.url.raw('resources/mini-hero/mini-hero-empty.png');
            var image = cc.textureCache.addImage(url);
            node.getChildByName('hero-order').getChildByName('defSkill').getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(image);
        }
        node.selectedAttk[0] = node.heroSelected;
        node.selectedAttk[1] = node.attackSkill;
        cc.loader.loadRes('hero-info', function(err, heroList) {
            for(var i = 0; i < heroList.current_fireteam.length; i++) {
                if(heroList.current_fireteam[i].heroID == node.heroSelected) {
                    var url = cc.url.raw(heroList.current_fireteam[i].icon);
                    var image = cc.textureCache.addImage(url);
                    node.getChildByName('hero-order').getChildByName('attkSkill').getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(image);
                }
            }
        });
    },

    defSkill_onClick: function() {
        var node = this.node.parent;
        if(node.selectedSupp[0] == node.heroSelected) {
            node.selectedSupp[0] = 'empty';
            node.selectedSupp[1] = 'empty';
            var url = cc.url.raw('resources/mini-hero/mini-hero-empty.png');
            var image = cc.textureCache.addImage(url);
            node.getChildByName('hero-order').getChildByName('suppSkill').getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(image);
        } else if(node.selectedAttk[0] == node.heroSelected){
            node.selectedAttk[0] = 'empty';
            node.selectedAttk[1] = 'empty';
            var url = cc.url.raw('resources/mini-hero/mini-hero-empty.png');
            var image = cc.textureCache.addImage(url);
            node.getChildByName('hero-order').getChildByName('attkSkill').getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(image);
        }
        node.selectedDef[0] = node.heroSelected;
        node.selectedDef[1] = node.defenseSkill;
        cc.loader.loadRes('hero-info', function(err, heroList) {
            for(var i = 0; i < heroList.current_fireteam.length; i++) {
                if(heroList.current_fireteam[i].heroID == node.heroSelected) {
                    var url = cc.url.raw(heroList.current_fireteam[i].icon);
                    var image = cc.textureCache.addImage(url);
                    node.getChildByName('hero-order').getChildByName('defSkill').getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(image);
                }
            }
        });
    },

    battleBtn_onClick: function() {  
        var node = this.node.parent;
        if(node.selectedAttk[0] != 'empty' && node.selectedDef[0] != 'empty' && node.selectedSupp != 'empty') {
            this.turn1 = false;
            this.turn = 'enemy';
            this.flag2 = true;
        }
        cc.log('Supp: ' + node.selectedSupp);
        cc.log('Attk: ' + node.selectedAttk);
        cc.log('Def: ' + node.selectedDef);
    },

    update: function(dt) {
        
        this.updateTimer += dt;
        if (this.updateTimer < this.updateInterval) {
            return;
        }
        this.updateTimer = 0;

        var node = this.node.parent;

        // update hero skill queue
        if(node.selectedSupp[0] == 'empty') {
            var url = cc.url.raw('resources/mini-hero/mini-hero-empty.png');
            var image = cc.textureCache.addImage(url);
            node.getChildByName('hero-order').getChildByName('suppSkill').getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(image);
        }
        if(node.selectedAttk[0] == 'empty') {
            var url = cc.url.raw('resources/mini-hero/mini-hero-empty.png');
            var image = cc.textureCache.addImage(url);
            node.getChildByName('hero-order').getChildByName('attkSkill').getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(image);
        }
        if(node.selectedDef[0] == 'empty') {
            var url = cc.url.raw('resources/mini-hero/mini-hero-empty.png');
            var image = cc.textureCache.addImage(url);
            node.getChildByName('hero-order').getChildByName('defSkill').getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(image);
        }

        if (this.turn == 'player') {
            if(this.turn1)
                return;
            else {

                var node = this.node.parent;

                cc.loader.loadRes('hero-info', function(err, heroList) {
                    for(var i = 0; i < heroList.current_fireteam.length; i++) {
                        if(heroList.current_fireteam[i].health.current == 0)
                            cc.director.loadScene('Main View');
                    }
                });
                // Only do once operations
                // Add Enemy Conditions
                if(this.flag) {
                    for(var i = 0; global.current_enemy_status_queue.length; i++) {
                        node.getChildByName('enemyController').getComponent('enemyController').registerDmg(null, global.current_enemy_status_queue[i].condition, global.current_enemy_status_queue[i].turn, global.current_enemy_status_queue[i].url);
                        global.current_enemy_status_queue.splice(i, 1);
                    }
                    this.flag = false;
                }
            }
        } else if (this.turn == 'enemy') {

            var node = this.node.parent;

            // Register current status effect
            if(this.flag2) {
                node.getChildByName('enemyController').getComponent('enemyController').registerStatusEffect();
                this.flag2 = false;
            }
            // Process Player Attacks
            cc.loader.loadRes('skill-info', function(err, skillList) {
                for(var i = 0; i < skillList.skillImg.length; i++) {
                    var skill = skillList.skillImg[i];
                    // Support Attack
                    if(node.selectedSupp[1] == skill.skillID) {
                        if(skill.combat.type == 'heal') {
                            cc.loader.loadRes('hero-info', function(err, heroList) {
                                for(var j = 0; j < heroList.current_fireteam.length; j++) {
                                    var currHero = heroList.current_fireteam[j];
                                    if ((currHero.health.current + skill.combat.value) >= currHero.health.total)
                                        currHero.health.current = currHero.health.total;
                                    else   
                                        currHero.health.current = currHero.health.current + skill.combat.value;
                                }
                            });
                        }
                        node.selectedSupp[0] = 'empty';
                        node.selectedSupp[1] = 'empty'; 
                    }
                    
                    // Main Attack
                    if(node.selectedAttk[1] == skill.skillID) {
                        if(skill.combat.type == 'dmg') {
                            node.getChildByName('enemyController').getComponent('enemyController').registerDmg(skill.combat.value);
                            var tempStatus = new Object();
                            tempStatus.condition = skill.combat.condition;
                            tempStatus.turn = skill.combat.turn;
                            tempStatus.url = skill.combat.statusImg;
                            global.current_enemy_status_queue.push(tempStatus);
                        }
                        node.selectedAttk[0] = 'empty';
                        node.selectedAttk[1] = 'empty';
                    }

                    // Defense Attack
                    if(node.selectedDef[1] == skill.skillID) {
                        if(skill.combat.type == 'block') {
                            node.getChildByName('playerController').getComponent('playerController').setBlock(skill.combat.value);
                        }
                        node.selectedDef[0] = 'empty';
                        node.selectedDef[1] = 'empty';
                    }
                }
            });

            // Register intent for current turn
            if(global.intent == 'normal') {
                cc.loader.loadRes('hero-info', function(err, heroInfo) {
                    for(var i = 0; i < heroInfo.current_fireteam.length; i++) {
                        var currentHero = heroInfo.current_fireteam[i];
                        if((currentHero.health.current-8) <= 0)
                            currentHero.health.current = 0;
                        else 
                            currentHero.health.current = currentHero.health.current - 8;
                    }
                });
            } else if(global.intent == 'block') {

            } else if(global.intent == 'buff') {

            } else if(global.intent == 'debuff') {

            }


            // Flush player skill queue
            // Set intent for next turn
            // End Enemy Turn
            if(node.selectedSupp[0] == 'empty' && node.selectedAttk[0] == 'empty' && node.selectedDef[0] == 'empty'){
                node.getChildByName('enemyController').getComponent('enemyController').setIntent();
                this.turn = 'player';
                this.flag = true;
            }
        }
    }

    // update (dt) {},
});
