// Learn cc.Class:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //     // ATTRIBUTES:
        //     default: null,        // The default value will be used only when the component attaching
        //                           // to a node for the first time
        //     type: cc.SpriteFrame, // optional, default is typeof default
        //     serializable: true,   // optional, default is true
        // },
        // bar: {
        //     get () {
        //         return this._bar;
        //     },
        //     set (value) {
        //         this._bar = value;
        //     }
        // },
        statusImage: {
            default: null,
            type: cc.Sprite
        },
        statusTurn: {
            default: null,
            type: cc.Label
        }
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},
    onLoad() {
        this.updateInterval = 0.15;
        this.updateTimer = 0;
    },

    init: function(statusType, statusUrl, statusTurn) {
        this.statusType = statusType;
        cc.log(this.statusType);
        cc.log(statusUrl);
        var url = cc.url.raw(statusUrl);
        var texture = cc.textureCache.addImage(url);
        this.statusImage.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(texture);
        this.statusTurn.getComponent(cc.Label).string = statusTurn;
    },

    start () {

    },

    update:function(dt) {

        this.updateTimer += dt;
        if (this.updateTimer < this.updateInterval) {
            return;
        }
        this.updateTimer = 0;
        var statusTurn = this.statusTurn;
        var node = this.node;

        var type =  this.statusType;
        cc.loader.loadRes('enemy-info', function(err, enemyInfo) {
            var exist = false;
            for(var i = 0; i < enemyInfo.enemy1.current_status.length; i++) {
                if(enemyInfo.enemy1.current_status[i].condition == type) {
                    statusTurn.getComponent(cc.Label).string = enemyInfo.enemy1.current_status[i].turn;
                    exist = true;
                }
            }
            if(!exist) {
                node.destroy();
            }
        });
    }

    // update (dt) {},
});
