window['global'] = {

    current_page: '',
    current_enemy_status_queue: [],
    intent: null
}