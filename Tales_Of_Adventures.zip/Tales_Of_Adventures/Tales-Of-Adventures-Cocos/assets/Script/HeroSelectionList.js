// Learn cc.Class:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {

        heroPrefab: {
            default: null,
            type: cc.Prefab
        }
    },

    onLoad() {
        var heroPrefab = this.heroPrefab;
        var node = this.node;
        cc.log(node.children);
        cc.loader.loadRes('hero-info', function(err, heroList) {
            for(let i = 0; i < heroList.available_fireteam.length; i++) {
                var hero = cc.instantiate(heroPrefab);
                var availableHero = heroList.available_fireteam[i];
                node.addChild(hero);
                hero.getComponent('HeroItemTemplate').init(availableHero.heroID, availableHero.name, availableHero.level, availableHero.img, availableHero.cost, true);
            }
            for(let i = 0; i < heroList.unlocked_fireteam.length; i++) {
                var hero = cc.instantiate(heroPrefab);
                var unlockedHero = heroList.unlocked_fireteam[i];
                node.addChild(hero);
                hero.getComponent('HeroItemTemplate').init(unlockedHero.heroID, unlockedHero.name, unlockedHero.level, unlockedHero.img, unlockedHero.cost, false);
            }
        });
    },

    start () {

    },

    addAnIcon: function(heroObject) {
        var hero = cc.instantiate(this.heroPrefab);
        this.node.addChild(hero);
        hero.getComponent('HeroItemTemplate').init(heroObject.heroID, heroObject.name, heroObject.level, heroObject.img, heroObject.cost, true)
    }

});
