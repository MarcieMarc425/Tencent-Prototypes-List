import './js/libs/weapp-adapter'
import './js/libs/symbol'

import Main from './js/main'

new Main()
